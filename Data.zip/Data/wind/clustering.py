# -*- coding: utf-8 -*-
"""
Created on Sat Jan 11 08:46:03 2025

@author: stjori

Agglomerative hierarchical clustering of the wind dataset(s)
"""

import pandas as pd
import numpy as np
from scipy.cluster.hierarchy import linkage, fcluster
import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist
from sklearn.preprocessing import StandardScaler

"""
Clusters to use for seasons: week_combined['Cluster_4_WS']
Clusters to use for weekdays: 
"""
#%%
"""
Load files
"""
electricity = pd.read_csv(r"C:\Data\electricity\electricity_demand.csv", parse_dates=['Datetime'])
wind = pd.read_csv(r"C:\Data\wind\average_pivot.csv", parse_dates=['Datetime'])

#%%
"""
Aggregate zones for each dataset to achieve clustered dataset across zones (not individual 192 clusters for each zone), drop, and rename
"""
electricity['Total'] = electricity.drop(columns=['Datetime']).sum(axis=1)
wind['Total'] = wind.drop(columns=['Datetime']).sum(axis=1)

electricity = electricity[['Datetime', 'Total']]
wind = wind[['Datetime', 'Total']]

electricity.rename(columns={'Total': 'Electricity'}, inplace=True)
wind.rename(columns={'Total': 'Wind'}, inplace=True)

#%%
"""
Merge datasets and add week and hour columns
"""
electricity['Datetime'] = pd.to_datetime(electricity['Datetime'], format="%d/%m/%Y %H:%M")

#Merge total electricity demand and wind power data into combined dataframes
combined_data = pd.merge(electricity, wind, on='Datetime')

#Create function to produce week, hour, day, and day type columns
def combined_data_function(combined_data):
    combined_data['Week'] = combined_data['Datetime'].dt.isocalendar().week
    combined_data['Hour'] = combined_data['Datetime'].dt.hour
    combined_data['Day'] = np.repeat(np.arange(1, 365), 24)
    combined_data['Day_type'] = combined_data['Datetime'].dt.weekday.apply(lambda x: 1 if x < 5 else 2)
    
    return combined_data

combined_data = combined_data_function(combined_data)

#%%
"""
Seasons
Create separate weekly aggregated datasets (both with and without wind) and add cosine/sinus columns
"""

def aggregate_to_week(combined_data):
    week_combined = pd.DataFrame({
        'Week': combined_data['Week'].unique(),
        'Electricity_week': [combined_data[combined_data['Week']==week]['Electricity'].sum() for week in combined_data['Week'].unique()],
        'Wind_week': [combined_data[combined_data['Week']==week]['Wind'].sum() for week in combined_data['Week'].unique()]
    })
    
    week_combined['Week_sin'] = np.sin(2 * np.pi * week_combined['Week'] / 52.0)
    week_combined['Week_cos'] = np.cos(2 * np.pi * week_combined['Week'] / 52.0)
    return week_combined

week_combined = aggregate_to_week(combined_data)


#%%
"""
Seasons
Prepare datasets for clustering and standardise data
"""

def prepare_clustering(week_combined):
        week_combined_cluster = week_combined[['Electricity_week', 'Wind_week', 'Week_sin', 'Week_cos']].values
        return week_combined_cluster

week_combined_cluster = prepare_clustering(week_combined)

def scale_data(week_combined_cluster):
    scaler = StandardScaler()
    week_combined_cluster_s = scaler.fit_transform(week_combined_cluster)
    return week_combined_cluster_s

week_combined_cluster_s = scale_data(week_combined_cluster)


#%%
"""
Define agglomerative hierarchical clustering and elbow method functions
#Z = linkage(data_to_cluster, method='ward') #produces linkage matrix (n-1) x 4 matrix 
#(rows are each step, where Columns 0 and 1 are the indiced of the merged clusters, 
#column 2 is distance which is measure of how similar the clusters are, 
#column 3 contains nr. of observations in newly formed cluster)
#labels = fcluster(Z, t=192, criterion='maxclust') #fcluster extracts flat clusters from hierarchical clustering defined by linkage matrix Z
#labels is array where each element represents cluster label assigned to each observation
#for 8736 observations, array of length 8736 with values ranging from 1 to 192 will be created
"""
# Function to perform clustering and assign labels
def perform_clustering(data, n_clusters):
    Z = linkage(data, method='ward')
    labels = fcluster(Z, t=n_clusters, criterion='maxclust')
    return labels, Z

def clustering(data, max_clusters):
    wcss = []
    for n_clusters in range(1, max_clusters + 1):
        Z = linkage(data, method='ward')
        labels = fcluster(Z, t=n_clusters, criterion='maxclust')
        wcss.append(np.sum([np.sum((data[labels == i] - np.mean(data[labels == i], axis=0)) ** 2) for i in range(1, n_clusters + 1)]))
    return wcss


#%%
"""
Check optimal nr. of clusters, week aggregates, with and without wind, standardised
2 clusters most optimal in both cases but 4 works well and may still be better given that is provides more data to the model
No need to run this except to check for optimal clusters
"""
max_clusters = 10

wcss_wcs = clustering(week_combined_cluster_s, max_clusters)

plt.figure(figsize=(10, 7))
plt.plot(range(1, max_clusters + 1), wcss_wcs, marker='o')
plt.title('Elbow Method for Optimal Number of Clusters, combined dataset')
plt.xlabel('Number of Clusters')
plt.ylabel('WCSS')
plt.show()

#%%
"""
4 Clusters, week aggregates, standardised, average year and stations data
"""

week_combined['Cluster_4_WS'], Z_4 = perform_clustering(week_combined_cluster_s, 4)

df = combined_data.copy()
df_2 = week_combined.copy()
df_2 = df_2[['Week', 'Cluster_4_WS']]

df_3 = pd.merge(df, df_2, on=['Week'])

df_4 = df_3.drop(columns=['Week', 'Hour'])
df_4['Cluster_4_WS'] = df_4['Cluster_4_WS'].replace({
    3: 'Winter',
    4: 'Spring',
    1: 'Summer',
    2: 'Fall'
})
df_4['Cluster_4_WS'] = df_4['Cluster_4_WS'].replace({
    'Winter': 1,
    'Spring': 2,
    'Summer': 3,
    'Fall': 4
})

most_representative_days = []

for season, group1 in df_4.groupby('Cluster_4_WS'):
    for daytype, group2 in group1.groupby('Day_type'):
        cluster_data = group2.drop(columns=['Datetime', 'Day_type', 'Cluster_4_WS', 'Day'])
        # Calculate the mean values for each day
        daily_means = cluster_data.groupby(group2['Day']).mean()
        # Calculate the centroid of the cluster
        cluster_centroid = daily_means.mean().values
        
        # Reshape cluster_centroid to match the expected input shape for cdist
        cluster_centroid_reshaped = cluster_centroid.reshape(1, -1)
        
        # Calculate distances from each day's mean to the cluster centroid
        distances = cdist(daily_means.values, cluster_centroid_reshaped)
        min_distance_index = np.argmin(distances)
        
        # Find the most representative day (index) from daily_means
        most_representative_day_index = daily_means.index[min_distance_index]
        
        # Retrieve the actual date from group2
        most_representative_day = group2[group2['Day'] == most_representative_day_index]['Datetime'].iloc[0].date()
        
        # Store the most representative day information
        most_representative_days.append({
            'Season': season,
            'Day_Type': daytype,
            'Most_Representative_Day': most_representative_day
        })


most_representative_days_df = pd.DataFrame(most_representative_days)

most_representative_days_df.to_csv(r"C:\Data\wind\AHC.csv")
