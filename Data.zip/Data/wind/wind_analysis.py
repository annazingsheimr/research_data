# -*- coding: utf-8 -*-
"""
Created on Sun Dec  8 13:06:13 2024

@author: stjori


1. Create shapefile from weather stations and create excel file with only those weather stations located in the land area where wind turbine
develeopment is allowed
2. Produce a filtered dataset with data for only those weather stations
3. Create dataset with average energy generation

"""


import pandas as pd
import chardet
import math
import geopandas as gpd
import numpy as np
from sklearn.ensemble import RandomForestRegressor

#%%
"""
Read the stod_sj file into a dataframe. 
"""

with open(r"C:\Data\wind\stod_sj.csv", 'rb') as f:
    result = chardet.detect(f.read())

encoding = result['encoding']

stod = pd.read_csv(r"C:\Data\wind\stod_sj.csv", encoding=encoding, delimiter='\t')

#%%
"""
Filter out weather stations that are not existent within weather data files in the weather station file. 
Note that the below data files could not be provided due to size but they are available at the Met Office of Iceland.
The files contain weather station data, including wind speeds, at the hourly level for the years indicated in the file name.
"""
files = [r"C:\Data\wind\wind_VG_19952024Vegagerdin\wind_VG_20202024._filtered.csv",  
         r"C:\Data\wind\wind_VI_19952024_VedurstofaIslandsLVLandsnet\stod_20202024._filtered.csv", 
         r"C:\Data\wind\wind_VG_19952024Vegagerdin\wind_VG_20102020.csv", 
         r"C:\Data\wind\wind_VI_19952024_VedurstofaIslandsLVLandsnet\stod_20102020.csv",
         r"C:\Data\wind\wind_VG_19952024Vegagerdin\wind_VG_2000_2010.csv",
         r"C:\Data\wind\wind_VI_19952024_VedurstofaIslandsLVLandsnet\stod_2000_2010.csv",
         r"C:\Data\wind\wind_VG_19952024Vegagerdin\wind_VG_1990_2000.csv", 
         r"C:\Data\wind\wind_VI_19952024_VedurstofaIslandsLVLandsnet\stod_1990_2000.csv"]

chunk_size = 100000

def collect_station_ids(chunk, station_ids):
    unique_ids = chunk['STOD'].unique()
    station_ids.update(unique_ids)
        
station_ids = set()

for file in files:
    for chunk in pd.read_csv(file, chunksize=chunk_size):
        collect_station_ids(chunk, station_ids)

filtered_stod = stod[stod['STOD'].isin(station_ids)]

#%%
"""
Create shapefile for ArcGIS to create map of weather stations. 
"""

df = filtered_stod[['STOD', 'BREIDD_Y', 'LENGD_X']]
df['LENGD_X'] = -abs(df['LENGD_X'])

gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df['LENGD_X'], df['BREIDD_Y']))

gdf.set_crs(epsg=4326, inplace=True)
gdf_utm = gdf.to_crs(epsg=32627)

output_file_path = r"C:\Data\wind\stod.shp"
gdf_utm.to_file(output_file_path)

"""
See methodology & data section of the research paper for details on the GIS constraints that were applied. 
These constraints then resulted in the file that is used below.
"""
    
#%%
"""
Upload weather station file. Only upload weather-station-years if weather station is included in that weather_stations file which
shows weather stations in areas where wind turbines are allowed to be built on according to GIS calculations. 
"""

weather_stations = pd.read_excel(r"C:\Data\wind\weather_stations.xlsx", sheet_name=r'Sheet1')
ws_ids = set(weather_stations['STOD'])

files_data = [r"C:\Data\wind\wind_VG_19952024Vegagerdin\wind_VG_20202024._filtered.csv",  
         r"C:\Data\wind\wind_VI_19952024_VedurstofaIslandsLVLandsnet\stod_20202024._filtered.csv", 
         r"C:\Data\wind\wind_VG_19952024Vegagerdin\wind_VG_20102020.csv", 
         r"C:\Data\wind\wind_VI_19952024_VedurstofaIslandsLVLandsnet\stod_20102020.csv",
         r"C:\Data\wind\wind_VG_19952024Vegagerdin\wind_VG_2000_2010.csv",
         r"C:\Data\wind\wind_VI_19952024_VedurstofaIslandsLVLandsnet\stod_2000_2010.csv",
         r"C:\Data\wind\wind_VG_19952024Vegagerdin\wind_VG_1990_2000.csv", 
         r"C:\Data\wind\wind_VI_19952024_VedurstofaIslandsLVLandsnet\stod_1990_2000.csv"]

chunk_size = 100000

def filter_station_ids(chunk, ws_ids):
    return chunk[chunk['STOD'].isin(ws_ids)]
 
filtered_data = []   
for file in files_data: 
    for chunk in pd.read_csv(file, chunksize=chunk_size):
        filtered_chunk = filter_station_ids(chunk, ws_ids)
        filtered_data.append(filtered_chunk)
        
filtered_df = pd.concat(filtered_data, ignore_index=True)
filtered_df = filtered_df[['STOD', 'TIMI', 'D', 'F']]

#%%
"""
This section produces the dataframe on which to build further analyses for the sensitivity analysis. 
First, weather stations with average wind speed of 5m/s are discarded.
Second, wind power output is calculated. 
"""
"""
Create stod dataframe with weather stations years that contain enough data and create stod_list from the result
"""

#Checking for duplicates: there are duplicates, needs to be handled, see below
duplicates = filtered_df[filtered_df.duplicated(['TIMI', 'STOD', 'F'], keep=False)]
print(f"Number of duplicate rows: {len(duplicates)}")

years = list(range(1990, 2024))

stod_data = []
for stod_key, group in filtered_df.groupby('STOD'):
    group['TIMI'] = pd.to_datetime(group['TIMI'])
    
    for year in years:
        filtered = group[group['TIMI'].dt.year == year]
        year_data = filtered['TIMI'].count()
        
        if not filtered.empty and year_data >= 8000:
            stod = {
                'STOD': stod_key, 
                'Year': year
            }
            stod_data.append(stod)

stod_df = pd.DataFrame(stod_data)

stod_list = set(stod_df['STOD'])

filtered_df2 = filtered_df[filtered_df['STOD'].isin(stod_list)]

duplicates_2 = filtered_df2[filtered_df2.duplicated(['TIMI', 'STOD'], keep=False)]
print(f"Number of duplicate rows: {len(duplicates_2)}")

duplicates_3 = filtered_df2[filtered_df2.duplicated(['TIMI', 'STOD', 'F'], keep=False)]
print(f"Number of duplicate rows: {len(duplicates_3)}")

filtered_df2 = filtered_df2.drop_duplicates(subset=['TIMI', 'STOD', 'F'])

duplicates_2 = filtered_df2[filtered_df2.duplicated(['TIMI', 'STOD'], keep=False)]
print(f"Number of duplicate rows: {len(duplicates_2)}")

"""
Allocate zones to weather stations and calculate wind power from wind speed - create final df to apply further operations on
"""
#Load dataframes to correspond a weather station to its zone
weather_station_id = weather_stations[['STOD', 'ZoneID']]
ws_zoneid = pd.read_excel(r"C:\Data\wind\weather_stations.xlsx", sheet_name=r'Sheet2')
ws_zoneid['Zone'].iloc[6] = 'NA'
filtered_df2['TIMI'] = pd.to_datetime(filtered_df2['TIMI'])

# #Create a dataframe with the weather stations that have high enough average wind speed over all years and that have enough data points
# final_df = filtered_df2[filtered_df2['STOD'].isin(stod_list_2)]
# final_df['TIMI'] = pd.to_datetime(final_df['TIMI'])
final_df_grouped = filtered_df2.groupby(['TIMI', 'STOD']).first().reset_index()

#Create a dataframe with a time column ranging from start of 1990 to end of 2023, at hourly interval, repeated for each zone
allyears_hours = pd.date_range(start='1990-01-01 00:00:00', end='2023-12-31 23:00:00', freq='H')
final_df2 = pd.DataFrame(([hour, stod] for hour in allyears_hours for stod in stod_list), columns=['TIMI', 'STOD'])

#Merge the dataframe with the wind speed data into the dataframe containing all hours between start of 1990 to end of 2023
final_df3 = pd.merge(final_df2, final_df_grouped, on=['TIMI', 'STOD'], how='left')

#Delete weather station and year pairs with too few datapoints
final_df3['Year'] = final_df3['TIMI'].dt.year
valid_groups = final_df3.groupby(['Year', 'STOD'])['F'].count().reset_index(name='count')
valid_groups = valid_groups[valid_groups['count'] >= 8000]
mask = final_df3.set_index(['Year', 'STOD']).index.isin(valid_groups.set_index(['Year', 'STOD']).index)
final_df4 = final_df3[mask]
final_df4 = final_df4.reset_index(drop=True)
nan_count = final_df4['F'].isna().sum()
print(f"Number of NaN values in 'F' column: {nan_count}")

final_df4['Hour'] = final_df4['TIMI'].dt.hour
final_df4['Day'] = final_df4['TIMI'].dt.day
final_df4['Month'] = final_df4['TIMI'].dt.month

#use random forest regression to fill in datapoints that are nan
final_df5 = pd.DataFrame()

for stod in stod_list: 
    stod_dataframe = final_df4[final_df4['STOD'] == stod]
    
    train_df = stod_dataframe.dropna(subset=['F'])
    X_train = train_df[['Hour', 'Day', 'Month', 'Year']]
    Y_train = train_df['F']
    
    predict_df = stod_dataframe[stod_dataframe['F'].isna()]
    X_predict = predict_df[['Hour', 'Day', 'Month', 'Year']]
    
    if not X_train.empty and not X_predict.empty:
        model = RandomForestRegressor(n_estimators=100, random_state=42)
        model.fit(X_train, Y_train)
        
        predicted_values = model.predict(X_predict)
        final_df4.loc[final_df4['STOD'] == stod, 'F'] = final_df4.loc[final_df4['STOD'] == stod, 'F'].combine_first(pd.Series(predicted_values, index=X_predict.index))
        
    final_df5 = pd.concat([final_df5, final_df4[final_df4['STOD'] == stod]])
    
final_df5 = final_df5.sort_values(by=['STOD', 'TIMI']).reset_index(drop=True)
nan_count = final_df4['F'].isna().sum()

final_df5 = final_df5.merge(weather_station_id, on='STOD')
final_df5 = final_df5.merge(ws_zoneid, on='ZoneID')
final_df5 = final_df5.drop('ZoneID', axis=1)

zones = set(final_df5['Zone'])
check_stod_zones = set(zip(final_df5['STOD'], final_df5['Zone']))

"""
Discard weather station with average wind speed under 5 m/s over all years they have data for
"""

stod_df2 = []
for stod_key, group in final_df5.groupby('STOD'):
    
    if stod_key in stod_list:
        stod_2 = {
            'STOD': stod_key, 
            'Avg wind speed': group['F'].mean()
        }
        stod_df2.append(stod_2)

stod_df2 = pd.DataFrame(stod_df2)
stod_df2 = stod_df2[stod_df2['Avg wind speed'] >= 5]

stod_list_2 = set(stod_df2['STOD'])

#Create a dataframe with the weather stations that have high enough average wind speed over all years
final_df6 = final_df5[final_df5['STOD'].isin(stod_list_2)]

zones = set(final_df6['Zone'])

#%%
"""
Use final_df6 dataframe to calculate the average wind speed scenario. 
First, for each zone, calculate the average wind speed across all data points available for all stations within each zone and take the average one
Second, out of those stations, find the year that produces the average out of all years for those zones
Result: stations for each zone to take wind data from and one year.
"""

final_df6 = final_df6.drop(['D', 'Hour', 'Day', 'Month'], axis=1)

# years_with_all_zones = final_df6.groupby('Year')['Zone'].nunique()
# valid_years = years_with_all_zones[years_with_all_zones == years_with_all_zones.max()].index
# final_df7 = final_df6[final_df6['Year'].isin(valid_years)]

years_with_all_stod = final_df6.groupby('Year')['STOD'].nunique()
valid_years_stod = years_with_all_stod[years_with_all_stod == years_with_all_stod.max()].index
final_df7 = final_df6[final_df6['Year'].isin(valid_years_stod)]

average = final_df7.groupby(['STOD', 'Zone'])['F'].mean().reset_index(name='Avg')

zones = set(final_df6['Zone'])
zones = set(final_df7['Zone'])

# Step 1: Calculate the mean of the means
mean_of_means = average['Avg'].mean()

# Step 2: Calculate absolute difference from the mean of means
average['Abs_Diff'] = abs(average['Avg'] - mean_of_means)

# Step 3: Find the station closest to the mean of means for each zone
average_stations = average.loc[average.groupby('Zone')['Abs_Diff'].idxmin()]
average_station_list = list(average_stations['STOD'])

final_df8 = final_df7[final_df7['STOD'].isin(average_station_list)]

# years_with_all_zones = final_df8.groupby('Year')['Zone'].nunique()
# valid_years = years_with_all_zones[years_with_all_zones == years_with_all_zones.max()].index
# final_df8 = final_df8[final_df8['Year'].isin(valid_years)]

zones = set(final_df8['Zone'])

average_2 = final_df8.groupby('Year')['F'].mean().reset_index(name='Avg_2')
mean_of_means_2 = average_2['Avg_2'].mean()
average_2['Abs_Diff_2'] = abs(average_2['Avg_2'] - mean_of_means_2)

average_year = average_2.loc[average_2['Abs_Diff_2'].idxmin()]

final_df9 = final_df8[final_df8['Year'] == average_year[0]]

zones = set(final_df9['Zone'])

check = final_df8[final_df8['Year'] == 2019]

#%%
"""
Calculate wind power using final_df9
"""
#Calculate wind power
def hub_height_speed(ws):
        return ws * (99/10)**0.1309
    
final_df9['Hub_height_speed'] = final_df9['F'].apply(hub_height_speed)

def wind_power(hub_height_speed):
    if hub_height_speed > 28 or hub_height_speed < 2.5:
        return 0
    elif 12 <= hub_height_speed <= 28:
        return 5.56
    else:
        power = 0.5*1e-6 * (hub_height_speed)**3 *math.pi * (80)**2 *1.225 *0.29 * 0.9
        return power

final_df9['Wind_MW'] = final_df9['Hub_height_speed'].apply(wind_power)

final_df9 = final_df9.drop(['Hub_height_speed', 'F'], axis=1)

#%%
"""
Prepare file for further analysis
"""

average_df = final_df9.drop(['Year', 'STOD'], axis=1).sort_values(by='TIMI').reset_index().copy()
average_df = average_df.drop('index', axis=1)
average_df = average_df[:-24*8]

average_df = average_df.rename({'Zone': 'z', 'Wind_MW': 'value'}, axis=1)
average_df['r'] = 'electricity'
average_df['h'] = np.repeat(np.arange(1, 8737), 8)
average_df = average_df.sort_values(by=['z', 'h'])
average_df = average_df.drop('TIMI', axis=1)
average_df.to_csv(r"C:\Data\wind\average.csv", index=False)

#Create format for AHC
average_df_pivot = average_df.drop('r', axis=1)
average_df_pivot = average_df_pivot.pivot(columns='z', values='value', index='h')
average_df_pivot['Datetime'] = pd.date_range(start='2022-01-03 00:00:00', end='2023-01-01 23:00:00', freq='H')
average_df_pivot = average_df_pivot.set_index('Datetime')
average_df_pivot.to_csv(r"C:\Data\wind\average_pivot.csv")