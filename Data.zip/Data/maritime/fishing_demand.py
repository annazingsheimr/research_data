#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 28 16:41:31 2024

@author: anna-bryndis
"""


"""
Calculate demand for fuel in fishing vessels 2050. 
- First create empty dataframe with zones as columns and datetime as index
- Use energy forecast numbers for fishing vessels in ktonnes of oil equivalent
  (small amount is battery-electric but can be ignored)
  
Product: df_3
"""

import pandas as pd
import numpy as np
import requests
import json

#%%
df = pd.DataFrame()

#%%
df['No. hour'] = range(0, 8736)

hours = np.tile(range(0, 24), 364)

df['!Hour'] = hours

def hours(hours):
    return f'{hours:02}:00'

df['!Hour'] = df['!Hour'].apply(hours)

#%%
#%%
df['AL'] = 0
df['HB'] = 0
df['NA'] = 0
df['NL'] = 0
df['RN'] = 0
df['SL'] = 0
df['VF'] = 0
df['VL'] = 0

#%%
df['!Year'] = 2022
df.loc[8712:, '!Year'] = 2023

#%%
def hours_to_days(hours):
    return hours // 24 + 3

df['No. days'] = df['No. hour'].apply(hours_to_days)
df['No. days'] = df['No. days'].apply(lambda x: 1 if x == 366 else x)

#%%
def assign_month(day):
    if day <= 31: 
        return 1 #January
    if day <= 31+28:
        return 2 #February
    if day <= 31+28+31:
        return 3 #March
    if day <= 31+28+31+30:
        return 4 #April
    if day <= 31+28+31+30+31:
        return 5 #May
    if day <= 31+28+31+30+31+30:
        return 6 #June
    if day <= 31+28+31+30+31+30+31:
        return 7 #July
    if day <= 31+28+31+30+31+30+31+31:
        return 8 #August
    if day <= 31+28+31+30+31+30+31+31+30:
        return 9 #September
    if day <= 31+28+31+30+31+30+31+31+30+31:
        return 10 #October
    if day <= 31+28+31+30+31+30+31+31+30+31+30:
        return 11 #November
    if day <= 31+28+31+30+31+30+31+31+30+31+30+31:
        return 12 #December

df['!Month'] = df['No. days'].apply(assign_month)

#%%
def assign_day(row):
    month = row['!Month']
    no_day = row['No. days']
    
    if month == 1:
        return no_day
    elif month == 2: 
        return no_day - 31
    elif month == 3:
        return no_day - (31 + 28)
    elif month == 4:
        return no_day - (31 + 28 + 31)
    elif month == 5:
        return no_day - (31 + 28 + 31 + 30)
    elif month == 6:
        return no_day - (31 + 28 + 31 + 30 + 31)
    elif month == 7:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30)
    elif month == 8:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31)
    elif month == 9:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31)
    elif month == 10:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30)
    elif month == 11:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31)
    elif month == 12:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30)
    elif month == 1 and row['Year'] == 2023:
        return 1
    
df['!Day'] = df.apply(assign_day, axis=1)

#%%
df['datetime'] = pd.to_datetime(df[['!Year', '!Month', '!Day']].astype(str).agg('-'.join, axis=1), format='%Y-%m-%d')

df['Datetime'] = df['datetime'].astype(str) + ' ' + df['!Hour']

#%%
df = df.drop(['No. hour', '!Hour', '!Year', 'No. days', '!Month', '!Day', 'datetime'], axis=1)

#%%
df = df.set_index('Datetime')

#%%
"""
Insert demand numbers and allocate to hour and zone. Changes according to scenario considered (different resources).
"""
total_fishing =   1407230/8760  #MWh
#%%
"""
Query to get data from Statistics Iceland for tonnage of fish delivered to ports
as indicator of where fuel is consumed. Data is by month which allows for indentification
of seasonal differences as well. 

"""

json_query = {
  "query": [
    {
      "code": "Fisktegund",
      "selection": {
        "filter": "item",
        "values": [
          "0"
        ]
      }
    },
    {
      "code": "Löndunarhöfn",
      "selection": {
        "filter": "item",
        "values": [
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9",
          "10",
          "11",
          "12",
          "13",
          "14",
          "15",
          "16",
          "17",
          "18",
          "19",
          "20",
          "21",
          "22",
          "23",
          "24",
          "25",
          "26",
          "27",
          "28",
          "29",
          "30",
          "31",
          "32",
          "33",
          "34",
          "35",
          "36",
          "37",
          "38",
          "39",
          "40",
          "41",
          "42",
          "43",
          "44",
          "45",
          "46",
          "47",
          "48",
          "49",
          "50",
          "51",
          "52",
          "53",
          "54",
          "55",
          "56",
          "57",
          "58",
          "59",
          "60",
          "61",
          "62",
          "63",
          "64",
          "65",
          "66",
          "67",
          "68",
          "69",
          "70",
          "71",
          "72",
          "73",
          "74",
          "75",
          "76",
          "77",
          "78",
          "79",
          "80",
          "81",
          "82",
          "83",
          "84"
        ]
      }
    },
    {
      "code": "Eining",
      "selection": {
        "filter": "item",
        "values": [
          "0"
        ]
      }
    },
    {
      "code": "Ár",
      "selection": {
        "filter": "item",
        "values": [
          "2022"
        ]
      }
    },
    {
      "code": "Mánuður",
      "selection": {
        "filter": "item",
        "values": [
          "0",
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9",
          "10",
          "11"
        ]
      }
    }
  ],
  "response": {
    "format": "json"
  }
}

url = 'https://px.hagstofa.is:443/pxis/api/v1/is/Atvinnuvegir/sjavarutvegur/aflatolur/londunarhafnir/SJA09042.px'

response = requests.post(url, json=json_query)

if response.status_code == 200: 
    data = response.json()
    print(json.dumps(data, indent=2)) #Go to termninal, set directory, and output as textfile to see structure of json format
else:
    data = None
    print(f'Error {response.status_code}')

#%%
"""
Check whether data is not none
Produce dataframe from the json query
Unit: tonnes
"""
if data: 
    list_of_columns = data['columns']
    columns = []
    for i in range(len(list_of_columns)):
        columns_values = list_of_columns[i]['code']
        columns.append(columns_values)
    
    list_of_data = data['data']
    key = []
    values = []
    for i in range(len(list_of_data)):
        data_key = list_of_data[i]['key']
        data_values = list_of_data[i]['values']
        key.append(data_key)
        values.append(data_values)
    
    table_data = [key_sublist + values_sublist for key_sublist, values_sublist in zip(key, values)]
    
    fishing_data = pd.DataFrame(table_data, columns=columns)
    
else:
    print('No data')

#%%
"""
Clean dataframe to make further calculations easier
"""

fishing_data = fishing_data.drop(['Eining', 'Fisktegund', 'Ár'], axis=1)
fishing_data = fishing_data.rename(columns={'Afli og verðmæti eftir löndunarhöfn, fisktegund og mánuðum 1982-2022': 'Afli'})

#%%
"""
Change type from string to integers. 
"""
fishing_data['Afli'] = fishing_data['Afli'].replace('..', '0')
fishing_data['Afli'] = fishing_data['Afli'].astype(int)

#%%
"""
Delete all ports that have no activity during the year. 
"""
df_fishing = []
for hofn, group in fishing_data.groupby('Löndunarhöfn'):
    if group['Afli'].sum() != 0:
        df_fishing.append(group)

fishing_data_2 = pd.concat(df_fishing, ignore_index=True)

#%%
"""
Sorting dataframe.
"""
fishing_data_2['Löndunarhöfn'] = fishing_data_2['Löndunarhöfn'].astype(int)
fishing_data_2['Mánuður'] = fishing_data_2['Mánuður'].astype(int)
fishing_data_2 = fishing_data_2.sort_values(['Löndunarhöfn', 'Mánuður'])

#%%
"""
To be able to allocate ports to zones (done separately in Excel: 'löndunarhafnir.xlsx')
"""
list_hafnir = fishing_data_2['Löndunarhöfn'].unique()

#%%
"""
Produce dataframe to allocate ports to respective zones.
"""
list_hafnir = pd.read_excel('/Data/maritime/löndunarhafnir.xlsx',
                            sheet_name='Sheet1')

#%%
"""
NA values from excel are converted to nan but should be NA strings. 
"""
list_hafnir['Zone'].dtype #object, meaning mixed values in column
type(list_hafnir.iloc[1][2]) #nan values are float

def nan_to_NA(zone):
    if pd.isna(zone):
        return 'NA'
    else: 
        return zone

list_hafnir['Zone'] = list_hafnir['Zone'].apply(nan_to_NA)

#%%
"""
Rename columns to be the same as in fishing_data_2 and drop excess column.
"""
list_hafnir = list_hafnir.rename(columns={'Löndunarhöfn' : 'Name'})
list_hafnir = list_hafnir.drop('Name', axis=1)
list_hafnir = list_hafnir.rename(columns={'No.' : 'Löndunarhöfn'})

#%%
"""
Combine dataframes to add 'Zone' to ports data.
"""
final = pd.merge(fishing_data_2, list_hafnir, on='Löndunarhöfn')

#%%
"""
Create monthly values for Zones by aggregating values per port per month based on Zone allocation.
"""
dataframe = []
for zone_month, group in final.groupby(['Mánuður', 'Zone']):
    group['Fish tonnage'] = group['Afli'].sum()
    group = group.drop(['Löndunarhöfn', 'Afli'], axis=1)
    
    dataframe.append(group)

final_2 = pd.concat(dataframe, ignore_index=True)

#%%
"""
Excess colums are dropped.
"""
final_2 = final_2.drop_duplicates(subset=['Mánuður', 'Zone'])

#%%
"""
Sort dataframe
"""

final_2 = final_2.sort_values(['Zone', 'Mánuður'])
#%%
"""
Calculate Zonal proportions (based on whole year). 
Calculate seasonality for each Zone individually.
"""
def calculate_prop_season(final_2):
    
    total = final_2['Fish tonnage'].sum()
    
    dataframe = []
    for zone, group in final_2.groupby('Zone'):
        group['Proportion'] = group['Fish tonnage'].sum() / total
        group['Seasonality'] = group['Fish tonnage'] / group['Fish tonnage'].mean()
        
        dataframe.append(group)
    
    final_3 = pd.concat(dataframe, ignore_index=True)
    
    return final_3

final_3 = calculate_prop_season(final_2)      

"""
Checks performed: 
    - Checks performed for proportion for HB and AL manually
    - Checks perfromed for seasonality for all months for AL
"""

#%%
"""
Check whether total fish tonnage across all months and zones is the same as given by the data provider
Statistics Iceland (2022 numnbers, all fish, all Icelandic ports)
Check whether sum of unique values of proportion is 1. 
"""
x = final_3['Fish tonnage'].sum()
x # excel: 1389534 and x = 1389537 so nearly the same
y = final_3['Proportion'].unique().sum()
y # 1.0

#%%
"""
Calculate hourly values of energy demand for fishing. 
- Calculate average hourly demand (total)
- Multiply average hourly demand (total) by proportion for each zone
"""

def proportion_demand(df, final_3):
    
    for zone, group in final_3.groupby('Zone'):
        proportion_value = group['Proportion'].iloc[0]
        df[zone] = total_fishing * proportion_value
        
    df_2 = df
    
    return df_2

df_2 = proportion_demand(df, final_3)

#%%
"""
Set month values to 1-12 instead of 0-11 for next step (see below).
"""
def set_month(month_no):
    return month_no + 1

final_3['Mánuður'] = final_3['Mánuður'].apply(set_month)

#%%
df_2.index

#%%
"""
Calculate hourly values of energy demand for fishing, including seasonality.
"""

def seasonality_demand(df_2, final_3):
    
    df_3 = df_2.copy()
    
    for zone_month, group in final_3.groupby(['Mánuður', 'Zone']):
        seasonality_value = group['Seasonality'].iloc[0]
        zone = zone_month[1] #retrieve zone
        month_value = zone_month[0] #retrieve month
        month = f"{month_value:02}" #convert to string and add 0 if number is one digit only
        
        mask = df_3.index.str.startswith(f"2022-{month}")
        df_3.loc[mask, zone] *= seasonality_value
        
    return df_3

df_3 = seasonality_demand(df_2, final_3)

"""
Checks performed: 
    - Values manually calculated for HB and AL and all months checked
    - Total sum of the dataframe is total_fishing value*8736, see below
"""
x = np.sum(df_3.values)
y = total_fishing * 8736

#%%
"""
Upload final output fishing demand to csv
"""

df_3.to_csv('/Data/maritime/fishing_demand.csv')
