#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 30 12:19:31 2024

@author: anna-bryndis
"""

import pandas as pd
#%%
"""
Create maritime demand csv file (shipping and fishing vessels)
"""
shipping = pd.read_csv('/Data/maritime/shipping_demand.csv')
fishing = pd.read_csv('/Data/maritime/fishing_demand.csv')

maritime = shipping + fishing

maritime['Datetime'] = pd.date_range(start='2022-01-03 00:00:00', end='2023-01-01 23:00:00', freq='H')

maritime['Datetime'] = maritime['Datetime'].astype(str)

def hour(string):
    return string[:-3]

maritime['Datetime'] = maritime['Datetime'].apply(hour)


maritime.to_csv('/Data/maritime/maritime_demand.csv')
