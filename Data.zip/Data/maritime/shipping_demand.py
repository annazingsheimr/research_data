#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 30 09:53:58 2024

@author: anna-bryndis
"""


"""
Calculate demand for fuel in shipping vessels 2050. 
- First create empty dataframe with zones as columns and datetime as index
- Then average total demand for 2050 across all hours

Product: df_2
"""

import pandas as pd
import numpy as np
import requests
import json

#%%
df = pd.DataFrame()

#%%
df['No. hour'] = range(0, 8736)

hours = np.tile(range(0, 24), 364)

df['!Hour'] = hours

def hours(hours):
    return f'{hours:02}:00'

df['!Hour'] = df['!Hour'].apply(hours)

#%%
#%%
df['AL'] = 0
df['HB'] = 0
df['NA'] = 0
df['NL'] = 0
df['RN'] = 0
df['SL'] = 0
df['VF'] = 0
df['VL'] = 0

#%%
df['!Year'] = 2022
df.loc[8712:, '!Year'] = 2023

#%%
def hours_to_days(hours):
    return hours // 24 + 3

df['No. days'] = df['No. hour'].apply(hours_to_days)
df['No. days'] = df['No. days'].apply(lambda x: 1 if x == 366 else x)

#%%
def assign_month(day):
    if day <= 31: 
        return 1 #January
    if day <= 31+28:
        return 2 #February
    if day <= 31+28+31:
        return 3 #March
    if day <= 31+28+31+30:
        return 4 #April
    if day <= 31+28+31+30+31:
        return 5 #May
    if day <= 31+28+31+30+31+30:
        return 6 #June
    if day <= 31+28+31+30+31+30+31:
        return 7 #July
    if day <= 31+28+31+30+31+30+31+31:
        return 8 #August
    if day <= 31+28+31+30+31+30+31+31+30:
        return 9 #September
    if day <= 31+28+31+30+31+30+31+31+30+31:
        return 10 #October
    if day <= 31+28+31+30+31+30+31+31+30+31+30:
        return 11 #November
    if day <= 31+28+31+30+31+30+31+31+30+31+30+31:
        return 12 #December

df['!Month'] = df['No. days'].apply(assign_month)

#%%
def assign_day(row):
    month = row['!Month']
    no_day = row['No. days']
    
    if month == 1:
        return no_day
    elif month == 2: 
        return no_day - 31
    elif month == 3:
        return no_day - (31 + 28)
    elif month == 4:
        return no_day - (31 + 28 + 31)
    elif month == 5:
        return no_day - (31 + 28 + 31 + 30)
    elif month == 6:
        return no_day - (31 + 28 + 31 + 30 + 31)
    elif month == 7:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30)
    elif month == 8:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31)
    elif month == 9:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31)
    elif month == 10:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30)
    elif month == 11:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31)
    elif month == 12:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30)
    elif month == 1 and row['Year'] == 2023:
        return 1
    
df['!Day'] = df.apply(assign_day, axis=1)

#%%
df['datetime'] = pd.to_datetime(df[['!Year', '!Month', '!Day']].astype(str).agg('-'.join, axis=1), format='%Y-%m-%d')

df['Datetime'] = df['datetime'].astype(str) + ' ' + df['!Hour']

#%%
df = df.drop(['No. hour', '!Hour', '!Year', 'No. days', '!Month', '!Day', 'datetime'], axis=1)

#%%
df = df.set_index('Datetime')

#%%
total_shipping =  1535160 / 8760 #MWh, total final energy demand for 2050 for shipping divided by hours

#%%
"""
Access both "from" and "to" goods (in tonnes) being transported to ports in Iceland in 2022 from 
Statistics Iceland. 
"""

url = 'https://px.hagstofa.is:443/pxis/api/v1/is/Umhverfi/5_samgongur/4_skip/SAM05103.px'

json_query = {
  "query": [
    {
      "code": "Hafnir",
      "selection": {
        "filter": "item",
        "values": [
          "1",
          "2",
          "3",
          "4",
          "5",
          "6",
          "7",
          "8",
          "9",
          "10",
          "11",
          "12",
          "13",
          "14",
          "15",
          "16",
          "17",
          "18",
          "19",
          "20"
        ]
      }
    },
    {
      "code": "Ár",
      "selection": {
        "filter": "item",
        "values": [
          "2022"
        ]
      }
    },
    {
      "code": "Vörur",
      "selection": {
        "filter": "item",
        "values": [
          "0"
        ]
      }
    }
  ],
  "response": {
    "format": "json"
  }
}

response = requests.post(url, json=json_query)

if response.status_code == 200: 
    data = response.json()
    print(json.dumps(data, indent=2)) #Go to termninal, set directory, and output as textfile to see structure of json format
else:
    data = None
    print(f'Error {response.status_code}')

#%%
"""
Check whether data is not none
Produce dataframe from the json query
Unit: tonnes
"""
if data: 
    list_of_columns = data['columns']
    columns = []
    for i in range(len(list_of_columns)):
        columns_values = list_of_columns[i]['code']
        columns.append(columns_values)
    
    list_of_data = data['data']
    key = []
    values = []
    for i in range(len(list_of_data)):
        data_key = list_of_data[i]['key']
        data_values = list_of_data[i]['values']
        key.append(data_key)
        values.append(data_values)
    
    table_data = [key_sublist + values_sublist for key_sublist, values_sublist in zip(key, values)]
    
    shipping_data = pd.DataFrame(table_data, columns=columns)
    
else:
    print('No data')

#%%
"""
Clean dataframe.
"""
shipping_data = shipping_data.drop(['Ár', 'Vörur'], axis=1)
shipping_data.columns = ['Tegund', 'Hafnir', 'Vöruflutningar']

#%%
"""
Calculate total tonnage (to and from) for the year for each port. 
"""
shipping_0 = shipping_data.loc[shipping_data['Tegund'] == '0'].copy()
shipping_1 = shipping_data.loc[shipping_data['Tegund'] == '1'].copy()

shipping_0['Vöruflutningar'] = shipping_0['Vöruflutningar'].replace('..', '0')
shipping_0['Vöruflutningar'] = shipping_0['Vöruflutningar'].astype(int)
shipping_1['Vöruflutningar'] = shipping_1['Vöruflutningar'].replace('..', '0')
shipping_1['Vöruflutningar'] = shipping_1['Vöruflutningar'].astype(int)

shipping_0.reset_index(drop=True, inplace=True)
shipping_1.reset_index(drop=True, inplace=True)

shipping_0['Vöruflutningar'] = shipping_0['Vöruflutningar'] + shipping_1['Vöruflutningar']

"""
Checked in excel. 
"""
#%%
"""
Load list of ports (allocated to zones). 
"""
list_hafnir = pd.read_excel('/Users/anna-bryndis/Desktop/Sustainable Energy Futures/Thesis/Data/Maritime/Python/shipping_ports.xlsx',
                            sheet_name='Sheet1')

def nan_to_NA(zone):
    if pd.isna(zone):
        return 'NA'
    else: 
        return zone

list_hafnir['Zone'] = list_hafnir['Zone'].apply(nan_to_NA)

#%%
"""
Add Zones column to shipping data.
"""
shipping_0['Zone'] = list_hafnir['Zone']

#%%
"""
Delete rows with values of 0.
"""
mask = shipping_0['Vöruflutningar'] == 0
shipping_0 = shipping_0[~mask]

#%%
shipping_0 = shipping_0.drop(['Tegund', 'Hafnir'], axis=1)

#%%
"""
Create shipping values by Zone
"""
dataframe = []
for zone, group in shipping_0.groupby(['Zone']):
    group['Shipping tonnage'] = group['Vöruflutningar'].sum()
    
    dataframe.append(group)

shipping_data_3 = pd.concat(dataframe, ignore_index=True)

"""
Checks performed in excel.
"""

#%%
"""
Excess colums are dropped.
"""
shipping_data_3 = shipping_data_3.drop('Vöruflutningar', axis=1)
shipping_data_3 = shipping_data_3.drop_duplicates(subset=['Zone', 'Shipping tonnage'])


"""
Checks performed in excel.
"""

#%%
"""
Proportion for each zone in terms of shipping tonnage calculated.
"""
def calculate_prop(shipping_data_3):
    
    total = shipping_data_3['Shipping tonnage'].sum()
    
    dataframe = []
    for zone, group in shipping_data_3.groupby('Zone'):
        group['Proportion'] = group['Shipping tonnage'].sum() / total
        
        dataframe.append(group)
    
    final = pd.concat(dataframe, ignore_index=True)
    
    return final

final = calculate_prop(shipping_data_3)

#%%
"""
Check whether total of new Proportion column equals one.
"""
x = final['Proportion'].sum()
x # 1

#%%
"""
Calculate hourly values of energy demand for shipping. 
- Calculate average hourly demand (total)
- Multiply average hourly demand (total) by proportion for each zone
"""

def proportion_demand(df, final):

    for zone, group in final.groupby('Zone'):
        proportion_value = group['Proportion'].iloc[0]
        df[zone] = total_shipping * proportion_value
        
    df_2 = df
    
    return df_2

df_2 = proportion_demand(df, final)

#%%
x = np.sum(df_2.values)
y = total_shipping * 8736

#%%
"""
Upload final output shipping demand to csv
"""
df_2.to_csv('/Data/maritime/shipping_demand.csv')
