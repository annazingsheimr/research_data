#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 22 09:48:42 2024

@author: anna-bryndis

Product: final_pivot_4
"""

# %%
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt

# %%
"""
Assign directory variable with file path to Load folders. 

Load data cannot be shared, thus, user has to upload their own data.
"""
directory = '/Data'

# %%
def load_data(directory):
    """
    Function to load individual files:
    - Joins directory and file name together to form file path
    - Reads the file and creates dataframe from it
    - Retrieves first two characters from fourth column into zone variable
    - Filter only year 2022 from dataframe into data dataframe
    - Rename columns
        Alm Forg: general consumption, not curtailable
        Alm Afg: general consumption, curtailable
        Stor Forg: energy intensive consumers demand, not curtailable
        Stor Afg: energy intensive consumers demand, curtailable
    - Add column with zeroes for datafile which lacks Stor Forg
    - Add new column called zone to differentiate data by zone later
    - Add data dataframe to the empty df dataframte
    - Concacenate (join together) all dataframes into one large
    
    Parameter: Directory
    Returns: Dataframe
    """
    
    df = []
    
    for file in os.listdir(directory):
        file_path = os.path.join(directory, file)
        #filename = os.path.basename(file_path)
        data = pd.read_csv(file_path)
        
        zone = data.columns[3][:2]

        data = data[data['!Year'] == 2022]
        
        string3 = "Alm Forg"
        string4 = "Alm Afg"
        string5 = "Stor Forg"
        string6 = "Stor Afg"
        #column3 = zone + " " + string3
        #column4 = zone + " " + string4
        column5 = zone + " " + string5
        #column6 = zone + " " + string6
        #num_column = data.shape[1]

        if data.shape[1] == 7:
            data = data.rename(columns={data.columns[3]:string3, data.columns[4]:string4, data.columns[5]:string5,
                                       data.columns[6]:string6})
            #for column_index in range(3, num_column):
                #if column_index ==  i and data.columns[column_index] == 'column' + str(i):
                    #data = data.rename(columns={data.columns[column_index]:'string' + str(i)})
                #elif column_index == i and data.columns[column_index] == 'column' + str(i+1):
                    #data.insert(column_index, 'string'+str(i), 0)
                #i = i+1
        elif data.shape[1] == 6 and data.columns[5] == column5:
            data[string6] = 0
            data = data.rename(columns={data.columns[3]:string3, data.columns[4]:string4, data.columns[5]:string5,
                                       data.columns[6]:string6})
            
        data['Zone'] = zone
        
        #print("DataFrame shape:", data.shape)
        #print("DataFrame head:\n", data.head())
        #print(type(data))
        
        df.append(data)

    dataframe = pd.concat(df, ignore_index=True)

    return dataframe

"""
Checks performed: 
    - CSV file for SV shows same numbers in 2022, first hour, as in the dataframe columns
    - Below, variable number_hours outputs 8736 hours for each zone, exactly 52*7*24
"""

#%%
dataframe = load_data(directory)

#%%
def calculate_variability(dataframe):
    """
    Calculates variability (proportion from the hourly average).
    - Combines Alm Forg and Alm Afg into Alm, same with Stor
    - Calculates hourly mean for each zone
    - Creates two new columns, based on Alm and Stor, where each hour's electricity consumption 
    is divided by the hourly mean, to produce proportions to the mean
    - Creates a dataframe with this data combined
    Parameters: pandas dataframe
    Returns: new dataframe
    """
    
    dataframe['Alm'] = dataframe['Alm Forg'] + dataframe['Alm Afg']
    dataframe['Stor'] = dataframe['Stor Forg'] + dataframe['Stor Afg']
        
    df = []
    for zone, group in dataframe.groupby('Zone'):
        mean_alm = group['Alm'].mean()
        mean_stor = group['Stor'].mean()
        group['Alm Var'] = group['Alm'] / mean_alm
        group['Stor Var'] = group['Stor'] / mean_stor 
            
        df.append(group)
            
    data = pd.concat(df, ignore_index=True)
    
    data = data.drop(['Alm Forg', 'Alm Afg', 'Stor Forg', 'Stor Afg'], axis=1)
    
    return data

"""
Checks performed: 
    - For Zone AL year 2022: data inserted to excel, Alm Forg and Alm Afg summed together => same as in new Alm column
    - For Zone Al year 2022: data inserted to excel, mean calculated for Alm and first hour divided by the mean => same
    as in Alm Var column
"""

#%%
data = calculate_variability(dataframe)

#%%
data['Stor Var'] = data['Stor Var'].fillna(0)

#%%
"""
Check number of hours in the year 2022 and whether number of hours is the same for all zones, which it should be
"""
number_hours = data.groupby('Zone')['Alm'].count() #8736 hours in 2022

#%%
def calculate_zone_prop(dataframe):
    """
    Calculatex the proportion of electricity that each zone consumes, out of the total. 
    Parameters: dataframe 
    Returns: smaller dataframe only with the zones and the two columns with proportions
    """
    
    total_alm = data['Alm'].sum() #alm electricity demand for the year in Iceland
    total_stor = data['Stor'].sum() #stor electricity demand for the year in Iceland
    total = total_alm + total_stor #total electricity demand in Iceland in 2022
    
    df = []
    for zone, group in dataframe.groupby('Zone'):
        group['Alm Prop'] = group['Alm'].sum() / total_alm
        group['Stor Prop'] = group['Stor'].sum() / total_stor
        group['Stor Prop'] = group['Stor Prop'].fillna(0)
        group['Total Prop'] = (group['Alm'].sum() + group['Stor'].sum()) / total
        
        df.append(group)
            
    zone_prop = pd.concat(df, ignore_index=True)
    zone_prop = zone_prop[['Zone', 'Alm Prop', 'Stor Prop', 'Total Prop']]
    
    zone_prop = zone_prop.drop_duplicates(subset = ['Zone', 'Alm Prop', 'Stor Prop', 'Total Prop'])
    
    return zone_prop

#%%
zone_prop = calculate_zone_prop(data)

#%%
"""
Double-check that sum of the proportion for both Alm and Stor are 1.
"""
print(zone_prop['Alm Prop'].sum())
print(zone_prop['Stor Prop'].sum())

#%% 
"""
Produce 2050 values of electricity consumption for the two types of electricity consumption, Alm and Stor. Done by
multiplying by the average hourly electricity consumption for each type in 2050 with the calculated variability from 
the mean and with the proportion of the zone from the total consumption (in 2022).
""" 
electricity_alm =   6458879/8760 #average hourly 2050 electricity demand in MWh for general usage, without road transport
electricity_stor = 20306874/8760 #average hourly 2050 electricity demand in MWh for energy intensive consumers
#gap = 289*1000 

df_merged = pd.merge(data, zone_prop, on='Zone')

df_merged['Alm 2050'] = electricity_alm * df_merged['Alm Var'] * df_merged['Alm Prop']
df_merged['Stor 2050'] = electricity_stor * df_merged['Stor Var'] * df_merged['Stor Prop']

df_merged['Total 2050'] = df_merged['Alm 2050'] + df_merged['Stor 2050']

#df_merged['Electricity Demand 2050'] = df_merged['Total 2050'] / df_merged['Total 2050'].sum() * gap
#Change relevant column name references to 'Electricity Demand 2050' from 'Total 2050'

"""
Checks performed: 
    - Done for first hour: Total 2050 is the sum of Alm 2050 and Stor 2050
    - Done for first hour Alm: Alm 2050 calculation is correct
    - Electricity Demand 2050 sum is 289*1000 (see below)
"""
#%%
"""
Deduct total estimated supply to produce gap. This will be minus at first but should be positive after road transport 
demand is added
"""

def calculate_2050_prop(df_merged):
    """
    Calculatex the proportion of electricity that each zone consumes, out of the total. 
    Parameters: dataframe 
    Returns: smaller dataframe only with the zones and the two columns with proportions
    """
    
    total2050 = df_merged['Total 2050'].sum() #total electricity demand in Iceland in 2050
    
    df = []
    for zone, group in df_merged.groupby('Zone'):
        group['Total 2050 Prop'] = group['Total 2050'].sum() / total2050
        
        df.append(group)
            
    total_prop = pd.concat(df, ignore_index=True)
    
    total_prop = total_prop[['Zone', 'Total 2050 Prop']]
    
    total_prop = total_prop.drop_duplicates(subset = ['Zone', 'Total 2050 Prop'])
    
    return total_prop

total_prop = calculate_2050_prop(df_merged)

print(total_prop['Total 2050 Prop'].sum()) #1.0

df_merged = pd.merge(df_merged, total_prop, on='Zone')

def deduct_gap(df_merged):
    """
    Calculates variability (proportion from the hourly average).
    - Combines Alm Forg and Alm Afg into Alm, same with Stor
    - Calculates hourly mean for each zone
    - Creates two new columns, based on Alm and Stor, where each hour's electricity consumption 
    is divided by the hourly mean, to produce proportions to the mean
    - Creates a dataframe with this data combined
    Parameters: pandas dataframe
    Returns: new dataframe
    """
        
    df = []
    for zone, group in df_merged.groupby('Zone'):
        mean_total2050 = group['Total 2050'].mean()
        group['Total 2050 Var'] = group['Total 2050'] / mean_total2050
            
        df.append(group)
            
    data = pd.concat(df, ignore_index=True)
    
    return data

df_merged = deduct_gap(df_merged)

electricity_supply = 29093*1000/8760

df_merged['New Total 2050'] = df_merged['Total 2050'] - electricity_supply * df_merged['Total 2050 Prop'] * df_merged['Total 2050 Var']

all_negative = (df_merged['New Total 2050'] <= 0).all()

non_negative_values = df_merged[df_merged['New Total 2050'] >= 0] #True

df_merged['Total 2050'] = df_merged['New Total 2050']

df_merged = df_merged.drop('New Total 2050', axis=1)
df_merged = df_merged.drop(['Total 2050 Var', 'Total 2050 Prop'], axis=1)

#%%

print(df_merged['Total 2050'].sum()) #output: -2320870.9808219257

#%%
df_merged['!Year'].dtype #output: int64

#%%
"""
To create datetime column: 
    - Create new column with hours from 1 - 8736 for each zone
    - Create column with months (1-12)
    - Redo !Year assigning 2023 to last day in dataset
    - Create !Day column (see assign-day)
    - Create !Hour Column with sequence of 24 hour intervals
"""
df = []
df_merged['!Month'] = 0

for zone, group in df_merged.groupby('Zone'):
    
    group['No. hour'] = range(1, 8736+1)
    
    def assign_no_day(hour):
        return (hour - 1) // 24 + 3
    
    group['No. day'] = group['No. hour'].apply(assign_no_day)
    
    group.loc[group['No. day'] == 366, 'No. day'] = 1
    
    group.loc[group['No. hour'] >= 8713, '!Year'] = 2023
    
    def assign_month(day):
        if day <= 31: 
            return 1 #January
        if day <= 31+28:
            return 2 #February
        if day <= 31+28+31:
            return 3 #March
        if day <= 31+28+31+30:
            return 4 #April
        if day <= 31+28+31+30+31:
            return 5 #May
        if day <= 31+28+31+30+31+30:
            return 6 #June
        if day <= 31+28+31+30+31+30+31:
            return 7 #July
        if day <= 31+28+31+30+31+30+31+31:
            return 8 #August
        if day <= 31+28+31+30+31+30+31+31+30:
            return 9 #September
        if day <= 31+28+31+30+31+30+31+31+30+31:
            return 10 #October
        if day <= 31+28+31+30+31+30+31+31+30+31+30:
            return 11 #November
        if day <= 31+28+31+30+31+30+31+31+30+31+30+31:
            return 12 #December
    
    group['!Month'] = group['No. day'].apply(assign_month)
    
    df.append(group)

df_datetime = pd.concat(df, ignore_index=True)
#%%
df_datetime['!Day'] = 0

def assign_day(row):
    month = row['!Month']
    no_day = row['No. day']
    
    if month == 1:
        return no_day
    elif month == 2: 
        return no_day - 31
    elif month == 3:
        return no_day - (31 + 28)
    elif month == 4:
        return no_day - (31 + 28 + 31)
    elif month == 5:
        return no_day - (31 + 28 + 31 + 30)
    elif month == 6:
        return no_day - (31 + 28 + 31 + 30 + 31)
    elif month == 7:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30)
    elif month == 8:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31)
    elif month == 9:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31)
    elif month == 10:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30)
    elif month == 11:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31)
    elif month == 12:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30)
    elif month == 1 and row['Year'] == 2023:
        return 1
        
df_datetime['!Day'] = df_datetime.apply(assign_day, axis=1)

"""
Checks performed: 
    - 2023 has Day 1, 2022 for Day 31 (last day in December). Next day is new zone with 2022 (day 3 in January)
    - Jan starts with 3 goes to 31, Feb from 1 to 28, etc. (for all months)
"""
#%%
"""
Producing !Hour column, 24 hour intervals (from 0 to 23)
"""
hours = np.tile(np.arange(0,24), 364*8)

print(len(hours)) #output: 69888

df_datetime['!Hour'] = hours

#%%
"""
Producing Datetime column to better see time of year and day
"""
df_datetime['Datetime'] = pd.to_datetime(df_datetime[['!Year', '!Month', '!Day']].astype(str).agg('-'.join, axis=1), format='%Y-%m-%d')

def format_hour(hour):
    return f"{hour:02}:00"

df_datetime['Formatted hour'] = df_datetime['!Hour'].apply(format_hour)

df_datetime['Datetime'] = df_datetime['Datetime'].astype(str) + ' ' + df_datetime['Formatted hour']

#%%
"""
To produce final demand matrix for electricity demand for model
"""

final = df_datetime.drop(['Formatted hour', 'No. day', 'No. hour', 'Stor 2050', 'Alm 2050'
                          , 'Total Prop', 'Stor Prop', 'Alm Prop', 'Stor Var', 'Alm Var', 'Stor', 'Alm'
                          , '!Year', 'Month', 'Hour', '!Month', '!Day', '!Hour'], axis=1)

final_pivot = final.pivot(index = 'Datetime', columns='Zone', values='Total 2050')

#%%
"""
Plot all electricity demand values for each zone
"""

final_pivot.plot(figsize=(25,12), subplots=True)
plt.show()

#%%
"""
Plot electricity demand in 2050 for each zone, comparing January 3rd with June 20th
"""
plot_11 = final_pivot[final_pivot.index.str.startswith('2022-02-04')]
plot_11.plot(figsize=(10,12), subplots=True)

plot_12 = final_pivot[final_pivot.index.str.startswith('2022-11-20')]
plot_12.plot(figsize=(10,12), subplots=True)

plot_21 = final_pivot[final_pivot.index.str.startswith('2022-02-21')]
plot_21.plot(figsize=(10,12), subplots=True)

plot_22 = final_pivot[final_pivot.index.str.startswith('2022-02-19')]
plot_22.plot(figsize=(10,12), subplots=True)

plot_31 = final_pivot[final_pivot.index.str.startswith('2022-07-18')]
plot_31.plot(figsize=(10,12), subplots=True)

plot_32 = final_pivot[final_pivot.index.str.startswith('2022-05-29')]
plot_32.plot(figsize=(10,12), subplots=True)

plot_41 = final_pivot[final_pivot.index.str.startswith('2022-09-16')]
plot_41.plot(figsize=(10,12), subplots=True)

plot_42 = final_pivot[final_pivot.index.str.startswith('2022-08-10')]
plot_42.plot(figsize=(10,12), subplots=True)

#%%
"""
Load proportion of Iceland's population for each zone to allocate transport demand (passenger cars and buses)
"""
population = pd.read_excel('/Data/electricity/Population.xlsx', sheet_name='Sheet2')

"""
Rectify nan to NA.
"""
population['Zone'][5] = 'NA'

#%%
"""
Trucks and vans energy demand equally distributed throughout the year and zones. 
"""
trucks_demand =  (830518/8760)/8 

final_pivot_2 = final_pivot.copy()

final_pivot_2 += trucks_demand

#%%
"""
Load bus load curve.
"""
bus_load_curve = pd.read_excel('/Data/electricity/bus_load_curve.xlsx', sheet_name='Sheet2')

#%%
"""
Create empty dataframe to perform operations on. 
"""
bus = final_pivot.copy()
bus = bus - bus

#%%
"""
Define bus energy demand and assign to zone and hour.
"""

bus_demand = 193025/8760 #in MWh energy demand, total for Iceland, per hour

def bus_demand_pop(population, bus): 

    for zone, group in population.groupby('Zone'):
        proportion = group['Proportion'].iloc[0]
        bus[zone] = proportion * bus_demand
    
    bus_2 = bus
        
    return bus_2

bus = bus_demand_pop(population, bus)

"""
Checks performed below
"""
x = np.sum(bus.values)
x #192496.1643835616
y =  193025/8760*8736
y #192496.16438356164

bus_load_curve['Hour'] = bus_load_curve['Hour'].astype(str)

def hour(string):
    return string[:-3]

bus_load_curve['Hour'] = bus_load_curve['Hour'].apply(hour)

def bus_demand_hour(bus_load_curve, bus):
    
    bus_2 = bus.copy()
    
    for index, row in bus_load_curve.iterrows():
        hour = row['Hour']
        bus_var = row['Bus Var']
        
        mask = bus_2.index.str.endswith(f"{hour}")
        bus_2.loc[mask] *= bus_var
        
    return bus_2

bus_2 = bus_demand_hour(bus_load_curve, bus)

z = np.sum(bus_2.values)
z #192496.16438356173

#%%
"""
Combine non-road transport related electricity + trucks with buses
"""
final_pivot_3 = final_pivot_2 + bus_2

#%%
"""
Load passenger car load curve.
"""
passenger_load_curve = pd.read_excel('/Data/electricity/passenger_load_curve.xlsx', sheet_name='Sheet2')

#%%
"""
Create empty dataframe to perform operations on. 
"""
passenger = final_pivot.copy()
passenger = passenger - passenger

#%%
"""
Define passenger car energy demand and assign to zone and hour.
"""

passenger_demand = 1529882/8760 #in MWh energy demand, total for Iceland, per hour

def passenger_demand_pop(population, passenger): 

    for zone, group in population.groupby('Zone'):
        proportion = group['Proportion'].iloc[0]
        passenger[zone] = proportion * passenger_demand
    
    passenger_2 = passenger
        
    return passenger_2

passenger = passenger_demand_pop(population, passenger)

"""
Checks performed below
"""
x = np.sum(passenger.values)
x # 1525690.5424657536
y = 1529882/8760*8736
y #1525690.5424657534

"""
Create hourly variability
"""

passenger_load_curve['Hour'] = passenger_load_curve['Hour'].astype(str)

def hour(string):
    return string[:-3]

passenger_load_curve['Hour'] = passenger_load_curve['Hour'].apply(hour)

def passenger_demand_hour(passenger_load_curve, passenger):
    
    passenger_2 = passenger.copy()
    
    for index, row in passenger_load_curve.iterrows():
        hour = row['Hour']
        passenger_var = row['Passenger Var']
        
        mask = passenger_2.index.str.endswith(f"{hour}")
        passenger_2.loc[mask] *= passenger_var
        
    return passenger_2

passenger_2 = passenger_demand_hour(passenger_load_curve, passenger)

z = np.sum(passenger_2.values)
z #1525690.5424657536

"""
Checks performed in excel.
"""

#%%
"""
Combine non-road transport related electricity + trucks with buses
"""
final_pivot_4 = final_pivot_3 + passenger_2

#%%
"""
Create csv from electricity demand final output dataframe

Note that this dataframe is not provided due to the underlying NDA
"""
final_pivot_4.to_csv('/Data/electricity/electricity_demand.csv')
