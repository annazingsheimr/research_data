#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 28 09:40:21 2024

@author: anna-bryndis
"""

"""
Calculate demand for fuel in aviation. International aviation only (airport located in Reykjanes Pensinsula, 
                                                                    so demand is zero everywhere else)
- First create empty dataframe with zones as columns and datetime as index
- Then average total demand for 2050 across all hours

Product: df
"""

import pandas as pd
import numpy as np

#%%
df = pd.DataFrame()

#%%
df['No. hour'] = range(0, 8736)

hours = np.tile(range(0, 24), 364)

df['!Hour'] = hours

def hours(hours):
    return f'{hours:02}:00'

df['!Hour'] = df['!Hour'].apply(hours)

#%%
#%%
df['AL'] = 0
df['HB'] = 0
df['NA'] = 0
df['NL'] = 0
df['RN'] = 0
df['SL'] = 0
df['VF'] = 0
df['VL'] = 0

#%%
df['!Year'] = 2022
df.loc[8712:, '!Year'] = 2023

#%%
def hours_to_days(hours):
    return hours // 24 + 3

df['No. days'] = df['No. hour'].apply(hours_to_days)
df['No. days'] = df['No. days'].apply(lambda x: 1 if x == 366 else x)

#%%
def assign_month(day):
    if day <= 31: 
        return 1 #January
    if day <= 31+28:
        return 2 #February
    if day <= 31+28+31:
        return 3 #March
    if day <= 31+28+31+30:
        return 4 #April
    if day <= 31+28+31+30+31:
        return 5 #May
    if day <= 31+28+31+30+31+30:
        return 6 #June
    if day <= 31+28+31+30+31+30+31:
        return 7 #July
    if day <= 31+28+31+30+31+30+31+31:
        return 8 #August
    if day <= 31+28+31+30+31+30+31+31+30:
        return 9 #September
    if day <= 31+28+31+30+31+30+31+31+30+31:
        return 10 #October
    if day <= 31+28+31+30+31+30+31+31+30+31+30:
        return 11 #November
    if day <= 31+28+31+30+31+30+31+31+30+31+30+31:
        return 12 #December

df['!Month'] = df['No. days'].apply(assign_month)

#%%
def assign_day(row):
    month = row['!Month']
    no_day = row['No. days']
    
    if month == 1:
        return no_day
    elif month == 2: 
        return no_day - 31
    elif month == 3:
        return no_day - (31 + 28)
    elif month == 4:
        return no_day - (31 + 28 + 31)
    elif month == 5:
        return no_day - (31 + 28 + 31 + 30)
    elif month == 6:
        return no_day - (31 + 28 + 31 + 30 + 31)
    elif month == 7:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30)
    elif month == 8:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31)
    elif month == 9:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31)
    elif month == 10:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30)
    elif month == 11:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31)
    elif month == 12:
        return no_day - (31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30)
    elif month == 1 and row['Year'] == 2023:
        return 1
    
df['!Day'] = df.apply(assign_day, axis=1)

#%%
df['datetime'] = pd.to_datetime(df[['!Year', '!Month', '!Day']].astype(str).agg('-'.join, axis=1), format='%Y-%m-%d')

df['Datetime'] = df['datetime'].astype(str) + ' ' + df['!Hour']

#%%
df = df.drop(['No. hour', '!Hour', '!Year', 'No. days', '!Month', '!Day', 'datetime'], axis=1)

#%%
df = df.set_index('Datetime')

#%%
"""
Calculation of total energy 2050 based on data from Orkustofnun (Eldsneytisspá 2016-2060) - demand is in MWh of fuel needed
"""
x = 11.630 * (524) * 1000
x
#%%
df['RN'] = x / 8760

#%%
df.to_csv('/Data/aviation/aviation_demand.csv')