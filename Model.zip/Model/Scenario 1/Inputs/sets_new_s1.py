# -*- coding: utf-8 -*-
"""
Created on Mon Nov  4 15:50:28 2024

@author: stjori

Sets for scenario 1 which includes e-ammonia and e-methanol in fuel mix for maritime sector
4 seasons
"""

import pandas as pd
#%%
"""
Create sets
"""

#Zones
zones = pd.DataFrame({
    'set': ['z'] *8,
    'value': ['AL', 'HB', 'NA', 'NL', 'RN', 'SL', 'VF', 'VL']
})

#Hourly intervals
hourly_intervals = {
    'set': ['h']*24, 
    'value': list(range(1,24+1))
 }

#Daily intervals, 2 day types (1 equals weekday and 2 equals weekendday)
daily_intervals = {
    'set': ['d']*2, 
    'value': [1, 2]
}

#Seasonal intervals, 4 seasons (1 for winter, 2 for spring, 3 for summer, 4 for fall)
seasonal_intervals = {
    'set': ['s']*4, 
    'value': list(range(1,4+1))
 }

#Direction of flow
flow = {
    'set': ['f']*2, 
    'value': ['out', 'in']
}

#Transport technologies
transport = {
    'set': ['t']*5, 
    'value': ['truck_hydrogen', 'truck_methanol', 'truck_ammonia', 'truck_diesel', 'truck_kerosene']
}

#Production/conversion technologies
conversion = {
    'set': ['c']*4, 
    'value': ['electrolysers', 'methanol_synthesis', 'HB', 'FT']
}

#Resource technologies
resources = {
    'set': ['r']*6, 
    'value': ['electricity', 'hydrogen', 'e-methanol', 'e-ammonia', 'e-diesel', 'e-kerosene']
}

#Storage technologies
storage = {
    'set': ['o']*6, 
    'value': ['large', 'tank_methanol', 'tank_ammonia', 'tank_diesel', 'tank_kerosene', 'battery']
}

sets_full_scenario4 = pd.concat([zones, pd.DataFrame(hourly_intervals), pd.DataFrame(daily_intervals), 
                                 pd.DataFrame(seasonal_intervals), pd.DataFrame(flow), pd.DataFrame(storage), 
                                 pd.DataFrame(transport), pd.DataFrame(conversion), pd.DataFrame(resources)], ignore_index=True)

#%%
"""
Create csv file with sets
"""
sets_full_scenario4.to_csv(r"C:\Model\Scenario_1\Inputs\sets_new_s1.csv", index=False)