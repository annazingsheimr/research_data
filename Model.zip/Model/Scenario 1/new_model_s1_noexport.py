# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 10:47:22 2025

@author: stjori

Model - Scenario 1_noexport:
       
"""

import pandas as pd
import sys
import pyomo.environ as pyo
import signal
import os

#%%
"""
Signal handling code: interruped output file generated when the kernel is manually interrupted
"""

#Global flag to indicate interruption
interrupted = False

#Define the signal handler
def signal_handler(signum, frame):
    global interrupted
    interrupted = True
    print("Interrupt signal received. Saving intermediate results...")

#Register the signal handler for interrupt signals
signal.signal(signal.SIGINT, signal_handler)

#Function to save the current results
def save_results(instance, txt_filename, excel_filename):
    with open(txt_filename, 'w') as f:
        original_stdout = sys.stdout
        sys.stdout = f
        instance.display()
        sys.stdout = original_stdout

    data = []

    for v in instance.component_objects(pyo.Var, active=True):
        var_object = getattr(instance, str(v))
        for index in var_object:
            if var_object[index].value is not None:
                if isinstance(index, tuple):
                    data.append([str(v)] + list(index) + [pyo.value(var_object[index])])
                else:
                    data.append([str(v), index, pyo.value(var_object[index])])

    # Convert data into a DataFrame
    df = pd.DataFrame(data)

    # Define columns based on maximum number of indices
    max_indices = max(df.apply(lambda x: len(x) - 2, axis=1))
    columns = ['Variable'] + [f'Index{i+1}' for i in range(max_indices)] + ['Value']

    # Add missing columns to DataFrame
    for i in range(len(df.columns), len(columns)):
        df[i] = None

    df.columns = columns

    # Save the DataFrame to an Excel file
    df.to_excel(excel_filename, index=False)
    
# %%
"""
Define base directory for files
"""
base_dir = r"C:\Model\Scenario_1\Inputs"

#%%
"""
Load data for sets and parameters and manipulate some of the data
"""

#Load sets
sets_full = pd.read_csv(os.path.join(base_dir, "sets_new_s1.csv"))
sets_full['value'].iloc[2] = 'NA'

#Load parameters
param_full = pd.read_csv(os.path.join(base_dir, "param_new_s1.csv"))
costs_full = pd.read_csv(os.path.join(base_dir, "cost_c_new_s1.csv"))
cap_min_full = pd.read_csv(os.path.join(base_dir, "capmin_c_new_s1.csv"))
cap_max_full = pd.read_csv(os.path.join(base_dir, "capmax_c_new_s1.csv"))
pricex_full = pd.read_csv(os.path.join(base_dir, "pricex_s1.csv"))
days_full = pd.read_csv(os.path.join(base_dir, "days.csv"))
efficiency_full = pd.read_csv(os.path.join(base_dir, "efficiency_c_r_s1.csv"))

#Load new parameters for transmission of electricity
flow_q_full = pd.read_csv(os.path.join(base_dir, "flow_q_r.csv"))
v_full = pd.read_excel(os.path.join(base_dir, "Transmission.xlsx"))
#nan to NA
v_full['z1'] = v_full['z1'].fillna('NA')
v_full['z2'] = v_full['z2'].fillna('NA')

#Load new parameters for transport of hydrogen, maritime fuel, and aviation fuel
cost_t_full = pd.read_csv(os.path.join(base_dir, "cost_t_new_s1.csv"))
t_capmin_full = pd.read_csv(os.path.join(base_dir, "capmin_t_new_s1.csv"))
t_capmax_full = pd.read_csv(os.path.join(base_dir, "capmax_t_new_s1.csv"))
flow_t_full = pd.read_csv(os.path.join(base_dir, "flow_t_new_s1.csv"))

#Load new parameters for storage
e_s_get_full = pd.read_csv(os.path.join(base_dir, "e_s_get_new_s1.csv"))
e_s_put_full = pd.read_csv(os.path.join(base_dir, "e_s_put_new_s1.csv"))
cost_s_full = pd.read_csv(os.path.join(base_dir, "cost_o_new_s1.csv"))
e_s_hold_full = pd.read_csv(os.path.join(base_dir, "e_hold_s_new_s1.csv"))
inj_s_full = pd.read_csv(os.path.join(base_dir, "inj_s_new_s1.csv"))
del_s_full = pd.read_csv(os.path.join(base_dir, "del_s_new_s1.csv"))
s_min_full = pd.read_csv(os.path.join(base_dir, "s_min_new_s1.csv"))
s_max_full = pd.read_csv(os.path.join(base_dir, "s_max_new_s1.csv"))

"""
----------------------------------------------------------------------------------------------------------------------------------------
"""

#Change this between wind data sets
weeks_full = pd.read_csv(os.path.join(base_dir, "weeks_new_average.csv"))
demand_full = pd.read_csv(os.path.join(base_dir, "demand_new_s1.csv"))
demand_full['z'] = demand_full['z'].fillna('NA')
wind_full = pd.read_csv(os.path.join(base_dir, "wind_new_s1.csv"))
wind_full['z'] = wind_full['z'].fillna('NA')

#Round wind power and demand values to two decimals to make model more efficient
wind_full['value'] = wind_full['value'].apply(lambda x: round(x, 3))
demand_full['value'] = demand_full['value'].apply(lambda x: round(x, 2))

#%%
"""
Define model type
"""
model = pyo.AbstractModel(name='Full Model Scenario 4 with Transmission, Transport, and Storage')

#%%
"""
Define sets
"""

#Conversion technologies:
model.c = pyo.Set(initialize=sets_full[sets_full['set'] == 'c']['value'].tolist())

#Zones: 'HB', 'AL', 'RN', 'SL', 'VL', 'NA', 'NL', 'VF'
model.z = pyo.Set(initialize=sets_full[sets_full['set'] == 'z']['value'].tolist())

#hours: 1-24
model.h = pyo.Set(initialize=sets_full[sets_full['set'] == 'h']['value'].astype(int).tolist(), domain=pyo.Integers)

#days: 1,2 
model.d = pyo.Set(initialize=sets_full[sets_full['set'] == 'd']['value'].astype(int).tolist(), domain=pyo.Integers)

#seasons: 1-4 
#model.s = pyo.Set(initialize=sets_full[sets_full['set'] == 's']['value'].astype(int).tolist(), domain=pyo.Integers)

#transport technologies: 'truck_hydrogen', 'truck_maritime', 'truck_aviation'
model.t = pyo.Set(initialize=sets_full[sets_full['set'] == 't']['value'].tolist())

model.r = pyo.Set(initialize=['electricity', 'hydrogen', 'e-methanol', 'e-ammonia', 'e-diesel', 'e-kerosene'])
model.o = pyo.Set(initialize=['large', 'tank_methanol', 'tank_ammonia', 'tank_diesel', 'tank_kerosene', 'battery'])
model.f = pyo.Set(initialize=['in', 'out'])

model.s = pyo.Set(initialize=[1, 2, 3, 4])

#%%
"""
Define parameters
"""
#Cost of wind turbines, of electricity delivery (fixed transmission cost), landarea per turbine, price of electricity transmission
model.cost_wt = pyo.Param(initialize=param_full['value'].iloc[0], domain=pyo.NonNegativeReals)
model.cost_del = pyo.Param(initialize=param_full['value'].iloc[1], domain=pyo.NonNegativeReals)
model.land = pyo.Param(initialize=param_full['value'].iloc[2], domain=pyo.NonNegativeReals)
model.ptransm = pyo.Param(initialize=param_full['value'].iloc[3], domain=pyo.NonNegativeReals)

#Cost of conversion technologies
cost_dict = {row['c']: row['value'] for index,row in costs_full.iterrows()}
model.cost = pyo.Param(model.c, initialize=cost_dict, domain=pyo.NonNegativeReals)

# #Exporting price of each resource in euros per MWh
# pricex_dict = {row['r']: row['value'] for index, row in pricex_full.iterrows()}
# model.px = pyo.Param(model.r, initialize=pricex_dict, domain=pyo.NonNegativeReals)

#Number of day_types per week: 
days_dict = {row['d']: row['value'] for index, row in days_full.iterrows()}
model.nd = pyo.Param(model.d, initialize=days_dict, domain=pyo.Integers)

#Number of weeks per season: 
seasons_dict = {row['s']: row['value'] for index, row in weeks_full.iterrows()}
model.ns = pyo.Param(model.s, initialize=seasons_dict, domain=pyo.Integers)

#Demand of resources by hour, day, and season in MW
demand_dict = {(row['r'], row['z'], row['h'], row['d'], row['s']): row['value'] for index, row in demand_full.iterrows()}
model.demand = pyo.Param(model.r, model.z, model.h, model.d, model.s, initialize=demand_dict, domain=pyo.Reals)

#Max wind power potential in MW by hour, day, and season in MW, per resource (0 for all others except electricity)
wind_dict = {(row['r'], row['z'], row['h'], row['d'], row['s']): row['value'] for index, row in wind_full.iterrows()}
model.wind = pyo.Param(model.r, model.z, model.h, model.d, model.s, initialize=wind_dict, domain=pyo.NonNegativeReals)

#Conversion efficiencies per resource and technology combination
efficiency_dict = {(row['r'], row['c']): row['value'] for index, row in efficiency_full.iterrows()}
model.e_c = pyo.Param(model.r, model.c, initialize=efficiency_dict, domain=pyo.Reals)

#Minimum capacities of technologies
capmin_dict = {row['c']: row['value'] for index, row in cap_min_full.iterrows()}
model.capmin = pyo.Param(model.c, initialize=capmin_dict, domain=pyo.NonNegativeReals)

#Maximum capacities of technologies
capmax_dict = {row['c']: row['value'] for index, row in cap_max_full.iterrows()}
model.capmax = pyo.Param(model.c, initialize=capmax_dict, domain=pyo.NonNegativeReals)

# #Transmission losses
# e_q_dict = {row['r']: row['value'] for index, row in e_q_full.iterrows()}
# model.eq = pyo.Param(model.r, initialize=e_q_dict, domain=pyo.NonNegativeReals)

#Flow directions
flow_q_dict = {(row['r'], row['f']): row['value'] for index, row in flow_q_full.iterrows()}
model.flowq = pyo.Param(model.r, model.f, initialize=flow_q_dict, domain=pyo.Reals)

#Binary variables for adjacency of zones
v_dict = {(row['z1'], row['z2']): row['value1'] for index, row in v_full.iterrows()}
model.v = pyo.Param(model.z, model.z, initialize=v_dict, domain=pyo.Binary)

q_limit_dict = {(row['z1'], row['z2']): row['value2'] for index, row in v_full.iterrows()}
model.q_limit = pyo.Param(model.z, model.z, initialize=q_limit_dict, domain=pyo.NonNegativeReals)

#Cost for transport technologies
cost_t_dict = {row['t']: row['value'] for index, row in cost_t_full.iterrows()}
model.cost_t = pyo.Param(model.t, initialize=cost_t_dict, domain=pyo.NonNegativeReals)

#Min and max capacities for transport technologies
t_capmin_dict = {row['t']: row['value'] for index, row in t_capmin_full.iterrows()}
model.t_capmin = pyo.Param(model.t, initialize=t_capmin_dict, domain=pyo.NonNegativeReals)
t_capmax_dict = {row['t']: row['value'] for index, row in t_capmax_full.iterrows()}
model.t_capmax = pyo.Param(model.t, initialize=t_capmax_dict, domain=pyo.NonNegativeReals)

#Flow directions for resources and transport types
flow_t_dict = {(row['r'], row['t'], row['f']): row['value'] for index, row in flow_t_full.iterrows()}
model.flow_t = pyo.Param(model.r, model.t, model.f, initialize=flow_t_dict, domain=pyo.Reals)

#Flow of resource for storage, get task
e_s_get_dict = {(row['r'], row['o'], row['f']): row['value'] for index, row in e_s_get_full.iterrows()}
model.e_s_get = pyo.Param(model.r, model.o, model.f, initialize=e_s_get_dict)

#Flow of resource for storage, put task
e_s_put_dict = {(row['r'], row['o'], row['f']): row['value'] for index, row in e_s_put_full.iterrows()}
model.e_s_put = pyo.Param(model.r, model.o, model.f, initialize=e_s_put_dict)

#cost of storage
cost_s_dict = {row['o']: row['value'] for index, row in cost_s_full.iterrows()}
model.cost_s = pyo.Param(model.o, initialize=cost_s_dict, domain=pyo.NonNegativeReals)

#flow of hold task
e_s_hold_dict = {(row['r'], row['o'], row['f']): row['value'] for index, row in e_s_hold_full.iterrows()}
model.e_s_hold = pyo.Param(model.r, model.o, model.f, initialize=e_s_hold_dict, domain=pyo.Reals)

#injectability, max in MW/10
inj_s_dict = {row['o']: row['value'] for index, row in inj_s_full.iterrows()}
model.inj_s = pyo.Param(model.o, initialize=inj_s_dict, domain=pyo.NonNegativeReals)

#injectability, max in MW/10
del_s_dict = {row['o']: row['value'] for index, row in del_s_full.iterrows()}
model.del_s = pyo.Param(model.o, initialize=del_s_dict, domain=pyo.NonNegativeReals)

#minimum storage capacity
s_min_dict = {row['o']: row['value'] for index, row in s_min_full.iterrows()}
model.s_min = pyo.Param(model.o, initialize=s_min_dict, domain=pyo.NonNegativeReals)

#maximum storage capacity
s_max_dict = {row['o']: row['value'] for index, row in s_max_full.iterrows()}
model.s_max = pyo.Param(model.o, initialize=s_max_dict, domain=pyo.NonNegativeReals)

#%%
"""
Define variables
"""

"""
Operational variables---------------------------------------------------------------------------------------------------------------
"""
#Positive variables
# model.X = pyo.Var(model.r, model.z, model.h, model.d, model.s, within=pyo.NonNegativeReals)
model.W = pyo.Var(model.r, model.z, model.h, model.d, model.s, within=pyo.NonNegativeReals)
model.CON = pyo.Var(model.c, model.z, model.h, model.d, model.s, within=pyo.NonNegativeReals)
model.Qrate = pyo.Var(model.z, model.z, model.h, model.d, model.s, within=pyo.NonNegativeReals)
model.Trate = pyo.Var(model.t, model.z, model.z, model.h, model.d, model.s,  within=pyo.NonNegativeReals)
model.Srate_put = pyo.Var(model.o, model.z, model.h, model.d, model.s, within=pyo.NonNegativeReals)
model.Srate_hold = pyo.Var(model.o, model.z, model.h, model.d, model.s, within=pyo.NonNegativeReals)
model.Srate_get = pyo.Var(model.o, model.z, model.h, model.d, model.s, within=pyo.NonNegativeReals)
model.I = pyo.Var(model.o, model.z, model.h, model.d, model.s, within=pyo.NonNegativeReals)
model.I_sim = pyo.Var(model.o, model.z, model.d, model.s, within=pyo.NonNegativeReals)
model.I_act = pyo.Var(model.o, model.z, model.d, model.s, within=pyo.NonNegativeReals)
#BATTERY INTEGRATION---------------------------------------------------------------------------------------------------------------
model.Srate_put_max = pyo.Var(model.o, model.z, within=pyo.NonNegativeReals)
model.Srate_get_max = pyo.Var(model.o, model.z, within=pyo.NonNegativeReals)
#----------------------------------------------------------------------------------------------------------------------------------

#Free variables 
model.C = pyo.Var(model.r, model.z, model.h, model.d, model.s)
model.Q = pyo.Var(model.r, model.z, model.h, model.d, model.s)
model.T = pyo.Var(model.r, model.z, model.h, model.d, model.s)
model.S = pyo.Var(model.r, model.z, model.h, model.d, model.s)
model.delta_d = pyo.Var(model.o, model.z, model.d, model.s)
model.delta_s = pyo.Var(model.o, model.z, model.s)
model.delta_y = pyo.Var(model.o, model.z)

#Binary variables - BATTERY INTEGRATION -------------------------------------------------------------------------------------------
model.y = pyo.Var(model.o, model.z, model.h, model.d, model.s, within=pyo.Binary)
model.b = pyo.Var(model.o, model.z, model.h, model.d, model.s, within=pyo.Binary)
model.g = pyo.Var(model.o, model.z, model.h, model.d, model.s, within=pyo.Binary)
#----------------------------------------------------------------------------------------------------------------------------------

"""
Design variables---------------------------------------------------------------------------------------------------------------------
"""
#Integer variables
model.N = pyo.Var(model.c, model.z, within=pyo.NonNegativeIntegers)
model.N_t = pyo.Var(model.t, model.z, within=pyo.NonNegativeIntegers)
model.N_s = pyo.Var(model.o, model.z, within=pyo.NonNegativeIntegers)
model.a = pyo.Var(model.o, model.z, )

data_dict = {
    'RN': 81,
    'HB': 439,
    'SL': 2011,
    'VL': 1639,
    'AL': 2359,
    'NL': 2001,
    'NA': 2230,
    'VF': 1231
}

def N_wt_bounds(model, zone):
    return (0, data_dict[zone])

model.N_wt = pyo.Var(model.z, within=pyo.NonNegativeIntegers, bounds=N_wt_bounds)


#%%
"""
Define objection function and constraints
"""

#Objective function
def obj_expression(model):
    return (
        model.cost_del +
        sum(model.cost_wt * model.N_wt[z] for z in model.z) +
        sum(model.cost[c] * model.N[c, z] for c in model.c for z in model.z) 
        # - sum(model.px[r] * model.X[r, z, h, d, s] * model.nd[d] * model.ns[s]
        #     for r in model.r for z in model.z for h in model.h for d in model.d for s in model.s)
        + sum(model.ptransm * model.Qrate[z1, z2, h, d, s] * 
                  model.nd[d] * model.ns[s] for z1 in model.z for z2 in model.z if z2 != z1 and model.v[z1, z2] == 1
                  for h in model.h for d in model.d for s in model.s) 
        + sum(model.cost_t[t] * model.N_t[t, z] for t in model.t for z in model.z) +
        sum(model.cost_s[o] * model.N_s[o, z] for o in model.o for z in model.z)
        )
model.Z = pyo.Objective(rule=obj_expression, sense=pyo.minimize)

# #Export constraint, all resources except electricity
# def export_constraint_rule(model, r, z, h, d, s):
#     if r == 'electricity':
#         return model.X[r, z, h, d, s] == 0
#     else:
#         return pyo.Constraint.Skip
# model.ExportC = pyo.Constraint(model.r, model.z, model.h, model.d, model.s, rule=export_constraint_rule)

#Wind power constraint
def wind_constraint_rule(model, r, z, h, d, s):
    if r == 'electricity':
        return model.W[r, z, h, d, s] <= model.wind[r, z, h, d, s] * model.N_wt[z]
    else:
        return model.W[r, z, h, d, s] == 0
model.WindBal = pyo.Constraint(model.r, model.z, model.h, model.d, model.s, rule=wind_constraint_rule)

#No wind turbines in VF
def no_wt_VF_constraint_rule(model, z):
    if z == 'VF':
        return model.N_wt[z] == 0
    else:
        return pyo.Constraint.Skip
model.NoWTVF = pyo.Constraint(model.z, rule=no_wt_VF_constraint_rule)

#Transmission net rate constraint
def Transmission_net_constraint_rule(model, r, z1, h, d, s):
    if r == 'electricity':
        return model.Q[r, z1, h, d, s] == (
            sum(model.Qrate[z1, z2, h, d, s]*(model.flowq[r,'out']) for z2 in model.z if z2 != z1 and model.v[z1, z2] == 1) +
            sum(model.Qrate[z2, z1, h, d, s]*(model.flowq[r, 'in']) for z2 in model.z if z2 != z1 and model.v[z2, z1] == 1)
        )
    else:
        return model.Q[r, z1, h, d, s] == 0
model.Transm_net = pyo.Constraint(model.r, model.z, model.h, model.d, model.s, rule=Transmission_net_constraint_rule)

def Transmission_min_constraint_rule(model, z1, z2, h, d, s):
    if z2 != z1 and model.v[z1, z2] == 1:
        return 0 <= model.Qrate[z1, z2, h, d, s]
    else: 
        return pyo.Constraint.Skip
model.Transm_min = pyo.Constraint(model.z, model.z, model.h, model.d, model.s, rule=Transmission_min_constraint_rule)

def Transmission_max_constraint_rule(model, z1, z2, h, d, s):
    if z2 != z1 and model.v[z1, z2] == 1:
        return model.Qrate[z1, z2, h, d, s] <= model.q_limit[z1, z2]
    else: 
        return pyo.Constraint.Skip
model.Transm_max = pyo.Constraint(model.z, model.z, model.h, model.d, model.s, rule=Transmission_max_constraint_rule)

#Transport net rate constraint
def Transport_net_constraint_rule(model, r, z1, h, d, s):
    if r == 'electricity':
        return model.T[r, z1, h, d, s] == 0
    else:
        return model.T[r, z1, h, d, s] == (
            sum(model.Trate[t, z1, z2, h, d, s]*(model.flow_t[r, t, 'out']) for t in model.t for z2 in model.z if z2 != z1) + 
            sum(model.Trate[t, z2, z1, h, d, s]*(model.flow_t[r, t, 'in']) for t in model.t for z2 in model.z if z2 != z1)
        )
model.Transp_net = pyo.Constraint(model.r, model.z, model.h, model.d, model.s, rule=Transport_net_constraint_rule)
    
#Transport rate constraint, max
def Transport_min_constraint_rule(model, t, z1, h, d, s):
    return model.t_capmin[t] * model.N_t[t, z1] <= sum(model.Trate[t, z1, z2, h, d, s] for z2 in model.z if z2 != z1)
model.Transp_min = pyo.Constraint(model.t, model.z, model.h, model.d, model.s, rule=Transport_min_constraint_rule)

#Transport rate constraint, min
def Transport_max_constraint_rule(model, t, z1, h, d, s):
    return sum(model.Trate[t, z1, z2, h, d, s] for z2 in model.z if z2 != z1) <= model.t_capmax[t] * model.N_t[t, z1] 
model.Transp_max = pyo.Constraint(model.t, model.z, model.h, model.d, model.s, rule=Transport_max_constraint_rule)

#Storage net rate constraint
def Storage_net_constraint_rule(model, r, z, h, d, s):
    return model.S[r, z, h, d, s] == (
        sum(model.Srate_put[o, z, h, d, s] * model.e_s_put[r, o, 'out'] + model.Srate_hold[o, z, h, d, s] * model.e_s_hold[r, o, 'out'] + 
        model.Srate_get[o, z, h, d, s] * model.e_s_get[r, o, 'in'] for o in model.o)
        )
model.Stor_net = pyo.Constraint(model.r, model.z, model.h, model.d, model.s, rule=Storage_net_constraint_rule)

#Storage rate put max definition - BATTERY INTEGRATION--------------------------------------------------------------------------------------------------------
def Battery_put_get_rule(model, o, z, h, d, s):
    if o == 'battery':
        return pyo.Constraint.Skip
    else:
        return model.y[o, z, h, d, s] == 0
model.Bat_putmax = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Battery_put_get_rule)

def Storage_putmax_definition_rule(model, o, z):
    return model.Srate_put_max[o, z] == model.N_s[o, z] * model.inj_s[o]
model.Stor_putmax_def = pyo.Constraint(model.o, model.z, rule=Storage_putmax_definition_rule)

#Storage rate get max definition - BATTERY INTEGRATION
def Storage_getmax_definition_rule(model, o, z):
    return model.Srate_get_max[o, z] == model.N_s[o, z] * model.del_s[o]
model.Stor_getmax_def = pyo.Constraint(model.o, model.z, rule=Storage_getmax_definition_rule)

#Storage rate put constraint - BATTERY INTEGRATION
def Storage_putmax_constraint_rule(model, o, z, h, d, s):
    if o == 'battery':
        return model.Srate_put[o, z, h, d, s] <= model.Srate_put_max[o, z] * model.y[o, z, h, d, s]
    else: 
        return model.Srate_put[o, z, h, d, s] <= model.Srate_put_max[o, z]
model.Stor_putmax = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Storage_putmax_constraint_rule)

#Storage rate get constraint - BATTERY INTEGRATION 
def Storage_getmax_constraint_rule(model, o, z, h, d, s):
    if o == 'battery':
        return model.Srate_get[o, z, h, d, s] <= model.Srate_get_max[o, z] * (1 - model.y[o, z, h, d, s])
    else: 
        return model.Srate_get[o, z, h, d, s] <= model.Srate_get_max[o, z]
model.Stor_getmax = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Storage_getmax_constraint_rule)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------

#Storage rate put constraint
def Storage_putmin_constraint_rule(model, o, z, h, d, s):
    return 0 <= model.Srate_put[o, z, h, d, s]
model.Stor_putmin = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Storage_putmin_constraint_rule)

#Storage rate get constraint
def Storage_getmin_constraint_rule(model, o, z, h, d, s):
    return 0 <= model.Srate_get[o, z, h, d, s]
model.Stor_getmin = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Storage_getmin_constraint_rule)

#Max inventory constraint
def Inventory_max_constraint_rule(model, o, z, h, d, s):
    return model.I[o, z, h, d, s] <= model.N_s[o, z] * model.s_max[o]
model.Inv_max = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_max_constraint_rule)

#Max inventory constraint
def Inventory_min_constraint_rule(model, o, z, h, d, s):
    return model.N_s[o, z] * model.s_min[o] <= model.I[o, z, h, d, s]
model.Inv_min = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_min_constraint_rule)

#Inventory rate constraint 
def Inventory_net_constraint_rule(model, o, z, h, d, s):
    return model.I[o, z, h, d, s] == (
            sum(model.Srate_put[o, z, h, d, s] * model.e_s_put[r, o, 'in'] + model.Srate_hold[o, z, h, d, s] * model.e_s_hold[r, o, 'in'] +
                model.Srate_get[o, z, h, d, s] * model.e_s_get[r, o, 'out'] for r in model.r)
        )
model.Inv_rate = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_net_constraint_rule)

#Storage rate hold constraint
#def Storage_hold_1_constraint_rule(model, z, d, s):
    #return model.Srate_hold[z, 1, d, s] == model.I_sim[z, d, s]
#model.Stor_hold = pyo.Constraint(model.z, model.d, model.s, rule=Storage_hold_1_constraint_rule)

#Storage hold constraint, all other hours
def Storage_hold_constraint_rule(model, o, z, h, d, s):
    if h == 1:
        return model.Srate_hold[o, z, h, d, s] == model.I_sim[o, z, d, s]
    else: 
        return model.Srate_hold[o, z, h, d, s] == model.I[o, z, h-1, d, s]
model.Stor_hold = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Storage_hold_constraint_rule)

#Inventory simulation cycle constraint
def Inventory_sim_constraint_rule(model, o, z, d, s):
    return model.I_sim[o, z, d, s] == (
            model.I_act[o, z, d, s] + ((model.nd[d] - 1) * model.delta_d[o, z, d, s] + (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2
        )
model.Inv_sim =pyo.Constraint(model.o, model.z, model.d, model.s, rule=Inventory_sim_constraint_rule)

#Change of inventory over day
def Delta_day_constraint_rule(model, o, z, d, s):
    return model.delta_d[o, z, d, s] == model.I[o, z, 24, d, s] - model.I_sim[o, z, d, s] 
model.Delta_day = pyo.Constraint(model.o, model.z, model.d, model.s, rule=Delta_day_constraint_rule)

#Change of inventory over week
def Delta_season_constraint_rule(model, o, z, s):
    return model.delta_s[o, z, s] == sum(model.delta_d[o, z, d, s] * model.nd[d] for d in model.d)
model.Delta_season = pyo.Constraint(model.o, model.z, model.s, rule=Delta_season_constraint_rule)

#Change of inventory over year
def Delta_year_constraint_rule(model, o, z):
    return model.delta_y[o, z] == sum(model.delta_s[o, z, s] * model.ns[s] for s in model.s)
model.Delta_year = pyo.Constraint(model.o, model.z, rule=Delta_year_constraint_rule)

def Delta_year_zero_constraint_rule(model, o, z):
    return model.delta_y[o, z] == 0
model.Delta_yearzero = pyo.Constraint(model.o, model.z, rule=Delta_year_zero_constraint_rule)

#Inventory actual cycle constraint connecting daytypes
def Inventory_act_day_constraint_rule(model, o, z, d, s):
    if d > 1:
        return model.I_act[o, z, d, s] == model.I_act[o, z, d-1, s] + model.nd[d-1] * model.delta_d[o, z, d-1, s] 
    else: 
        return pyo.Constraint.Skip
model.Inv_actday = pyo.Constraint(model.o, model.z, model.d, model.s, rule=Inventory_act_day_constraint_rule)

#Inventory actual cycle constraint connecting seasons
def Inventory_act_season_constraint_rule(model, o, z, s):
    if s > 1:
        return model.I_act[o, z, 1, s] == model.I_act[o, z, 1, s-1] + model.ns[s-1] * model.delta_s[o, z, s-1]
    else: 
        return pyo.Constraint.Skip
model.Inv_actseason = pyo.Constraint(model.o, model.z, model.s, rule=Inventory_act_season_constraint_rule)

def Inventory_min_1_constraint_rule(model, o, z, h, d, s):
    return model.s_min[o] * model.N_s[o, z] <= (
            model.I[o, z, h, d, s] - ((model.nd[d] - 1) * model.delta_d[o, z, d, s] + (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2
        )
model.Inv_min_1 = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_min_1_constraint_rule)

def Inventory_min_2_constraint_rule(model, o, z, h, d, s):
    return model.s_min[o] * model.N_s[o, z] <= (
            model.I[o, z, h, d, s] - ((model.nd[d] - 1) * model.delta_d[o, z, d, s] - (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2
        )
model.Inv_min_2 = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_min_2_constraint_rule)

def Inventory_min_3_constraint_rule(model, o, z, h, d, s):
    return model.s_min[o] * model.N_s[o, z] <= (
            model.I[o, z, h, d, s] + ((model.nd[d] - 1) * model.delta_d[o, z, d, s] - (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2
        )
model.Inv_min_3 = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_min_3_constraint_rule)

def Inventory_min_4_constraint_rule(model, o, z, h, d, s):
    return model.s_min[o] * model.N_s[o, z] <= (
            model.I[o, z, h, d, s] + ((model.nd[d] - 1) * model.delta_d[o, z, d, s] + (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2
        )
model.Inv_min_4 = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_min_4_constraint_rule)

def Inventory_max_1_constraint_rule(model, o, z, h, d, s):
    return model.I[o, z, h, d, s] - ((model.nd[d] - 1) * model.delta_d[o, z, d, s] + (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2 <= (
            model.s_max[o] * model.N_s[o, z] 
        )
model.Inv_max_1 = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_max_1_constraint_rule)

def Inventory_max_2_constraint_rule(model, o, z, h, d, s):
    return model.I[o, z, h, d, s] - ((model.nd[d] - 1) * model.delta_d[o, z, d, s] - (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2 <= (
            model.s_max[o] * model.N_s[o, z] 
        )
model.Inv_max_2 = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_max_2_constraint_rule)

def Inventory_max_3_constraint_rule(model, o, z, h, d, s):
    return model.I[o, z, h, d, s] + ((model.nd[d] - 1) * model.delta_d[o, z, d, s] - (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2 <= (
            model.s_max[o] * model.N_s[o, z] 
        )
model.Inv_max_3 = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_max_3_constraint_rule)

def Inventory_max_4_constraint_rule(model, o, z, h, d, s):
    return model.I[o, z, h, d, s] + ((model.nd[d] - 1) * model.delta_d[o, z, d, s] + (model.ns[s] - 1) * model.delta_s[o, z, s]) / 2 <= (
            model.s_max[o] * model.N_s[o, z] 
        )
model.Inv_max_4 = pyo.Constraint(model.o, model.z, model.h, model.d, model.s, rule=Inventory_max_4_constraint_rule)

#Resource balance
def ReBal_constraint_rule(model, r, z, h, d, s):
    return model.W[r, z, h, d, s] + model.C[r, z, h, d, s] + model.Q[r, z, h, d, s] + model.T[r, z, h, d, s] + model.S[r, z, h, d, s] >= model.demand[r, z, h, d, s] # + model.X[r, z, h, d, s]
model.ReBal = pyo.Constraint(model.r, model.z, model.h, model.d, model.s, rule=ReBal_constraint_rule)

#Conversion constraint
def conversion_constraint_rule(model, r, z, h, d, s):
    return model.C[r, z, h, d, s] == sum(model.CON[c, z, h, d, s] * model.e_c[r, c] for c in model.c)
model.ConvC = pyo.Constraint(model.r, model.z, model.h, model.d, model.s, rule=conversion_constraint_rule)

#Minimum capacity constraint
def min_capacity_constraint_rule(model, c, z, h, d, s):
    return model.N[c, z] * model.capmin[c] <= model.CON[c, z, h, d, s]
model.MinCapC = pyo.Constraint(model.c, model.z, model.h, model.d, model.s, rule=min_capacity_constraint_rule)

#Maximum capacity constraint
def max_capacity_constraint_rule(model, c, z, h, d, s):
    return model.CON[c, z, h, d, s] <= model.N[c, z] * model.capmax[c]
model.MaxCapC = pyo.Constraint(model.c, model.z, model.h, model.d, model.s, rule=max_capacity_constraint_rule)

#%%
"""
Run the model with decomposition and save results
"""
# Create instance of the model
instance = model.create_instance()

with open('instance_output_new_s1_noexport.txt', 'w') as f:
    original_stdout = sys.stdout
    sys.stdout = f
    instance.pprint()
    sys.stdout = original_stdout
    
solver = pyo.SolverFactory('gurobi') #glpk or gurobi
solver.options['mipgap'] = 0.03
solver.options['Presolve'] = 2
solver.options['Method'] = 3
solver.options['BarHomogeneous'] = 1
solver.options['FeasibilityTol'] = 1e-5  
solver.options['IntFeasTol'] = 1e-5

try:
    results = solver.solve(instance, tee=True)  # Time limit in seconds
except KeyboardInterrupt:
    interrupted = True

# Check if the solver was interrupted
if interrupted:
    save_results(instance, 'solver_output_interrupted_new_s1_noexport.txt', 'output_file_interrupted_new_s1_noexport.xlsx')
else:
    save_results(instance, 'solver_output_new_s1_noexport.txt', 'output_file_new_s1_noexport.xlsx')
    
    
for z in instance.z:
    print(f"Number of wind turbines in zone {z}: {pyo.value(instance.N_wt[z])}")
    