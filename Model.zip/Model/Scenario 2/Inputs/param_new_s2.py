# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 11:09:32 2025

@author: stjori
"""

import os
import pandas as pd
import math

# %%
# Define base directory for files
base_dir = r"C:\Model\Scenario_2\Inputs"

# %%
"""
Parameters regarding:
    - Cost(capex and opex annualised per unit) of wind turbines - 5.56 MW
    - Fixed costs of electricity delivery
    - Landarea footprint per wind turbine
    - Price of electricity transmission
"""
# Cost of wind turbine (100kEUR per unit per year), cost of delivery of electricity (fixed, 100kEUR per year), land area per wind turbine in m2/1e8
param_df = pd.DataFrame({
    'param': ['cost_wt', 'cost_delivery', 'land_wt', 'ptransm'],
    'value': [8.46, 20.5, round(math.pi * (5*80)**2 / 1e8, 3), 0.001]
})

param_df.to_csv(os.path.join(base_dir, "param_new_s2.csv"), index=False)

# %%
"""
Parameters for days and seasons (weeks)
"""

# five weekdays and two weekenddays
days_df = pd.DataFrame({
    'd': [1, 2],
    'value': [5, 2]
})

days_df.to_csv(os.path.join(base_dir, "days.csv"), index=False)

weeks_df = pd.DataFrame({
    's': [1, 2, 3, 4],
    'value': [3, 13, 19, 17]
})


weeks_df.to_csv(os.path.join(base_dir, "weeks_new_average.csv"), index=False)


# %%
"""
Available land area parameter
"""

# in m2/1e8
landarea_df = pd.DataFrame({
    'z': ['RN', 'HB', 'SL', 'VL', 'AL', 'NL', 'NA', 'VF'],
    'value': [0.41, 2.21, 10.11, 8.24, 11.86, 10.06, 11.21, 6.19]
})

landarea_df.to_csv(os.path.join(base_dir, "landarea.csv"), index=False)

#%%
"""
Export prices for all resources except electricity
"""

pricex_df = pd. DataFrame({
    'r': ['electricity'] + ['hydrogen'] + ['e-diesel'] + ['e-kerosene'],
    'value': [0, 0.007, 0.004, 0.025]
})

pricex_df.to_csv(os.path.join(base_dir, "pricex_s2.csv"), index=False)

# %%
"""
Parameters for conversion technologies c
"""
cost_df = pd.DataFrame({
    'c': ['electrolysers', 'FT'],
    'value': [184, 822]
})

cost_df.to_csv(os.path.join(base_dir, "cost_c_new_s2.csv"), index=False) #new costs because WACC is set at 6%

#Capacity in MW/10
cap_min_chemical = 145/10  # 0.7*0.69*300
cap_max_chemical = round(1*0.69*300/10, 2)

cap_min_df = pd.DataFrame({
    'c': ['electrolysers', 'FT'],
    'value': [0, cap_min_chemical]
})

cap_min_df.to_csv(os.path.join(base_dir, "capmin_c_new_s2.csv"), index=False)

cap_max_df = pd.DataFrame({
    'c': ['electrolysers', 'FT'],
    'value': [300/10, cap_max_chemical]
})

cap_max_df.to_csv(os.path.join(base_dir, "capmax_c_new_s2.csv"), index=False)

efficiency_df = pd.DataFrame({
    'r': ['electricity']*2 + ['hydrogen']*2 + ['e-diesel']*2 + ['e-kerosene']*2,
    'c': ['electrolysers', 'FT']*4,
    'value': [-1, 0, 0.69, -1, 0, 0.314, 0, 0.314]
})

efficiency_df.to_csv(os.path.join(
    base_dir, "efficiency_c_r_s2.csv"), index=False)

# %%
"""
Parameters for electricity transmission
"""

flow_q_df = pd.DataFrame({
    'r': ['electricity']*2,
    'f':  ['out', 'in'],
    'value': [-1, 1]
})

flow_q_df.to_csv(os.path.join(base_dir, "flow_q_r.csv"), index=False)

# %%
"""
Transport parameters
"""

# Unit: 100kEUR per year per truck
cost_t_df = pd.DataFrame({
    't': ['truck_hydrogen', 'truck_diesel', 'truck_kerosene'],
    'value': [0.67, 0.84, 0.84]
})

cost_t_df.to_csv(os.path.join(base_dir, "cost_t_new_s2.csv"), index=False) #new due to e-diesel and e-kerosene separation and new WACC (6%)


# Unit: capacity in MW/10 per type of truck
t_capmin_df = pd.DataFrame({
    't': ['truck_hydrogen', 'truck_diesel', 'truck_kerosene'],
    'value': [round(0.7/4.5, 1), 0, 0]
})

t_capmax_df = pd.DataFrame({
    't': ['truck_hydrogen', 'truck_diesel', 'truck_kerosene'],
    'value': [round(2.2/4.5, 1), round(10.5/4.5, 1), round(10.5/4.5, 1)]
})

t_capmin_df.to_csv(os.path.join(base_dir, "capmin_t_new_s2.csv"), index=False) #new due to e-diesel and e-kerosene separation and new WACC (6%)
t_capmax_df.to_csv(os.path.join(base_dir, "capmax_t_new_s2.csv"), index=False) #new due to e-diesel and e-kerosene separation and new WACC (6%)


flow_t_df = pd.DataFrame({
    'r': ['hydrogen']*2*3 + ['e-diesel']*2*3 + ['e-kerosene']*2*3,
    't': ['truck_hydrogen', 'truck_hydrogen', 'truck_diesel', 'truck_diesel', 'truck_kerosene', 'truck_kerosene']*3,
    'f': ['out', 'in']*3*3,
    'value': [-1, 1, 0, 0, 0, 0, 0, 0, -1, 1, 0, 0, 0, 0, 0, 0, -1, 1]
})

flow_t_df.to_csv(os.path.join(base_dir, "flow_t_new_s2.csv"), index=False) #new due to e-diesel and e-kerosene separation and new WACC (6%)

# %%
"""
Storage parameters
"""

cost_s_df = pd.DataFrame({
    'o':  ['large', 'tank_diesel', 'tank_kerosene', 'battery'],
    'value': [93, 0, 0, 0.6]
})

cost_s_df.to_csv(os.path.join(base_dir, "cost_o_new_s2.csv"), index=False) #new because of battery addition, WACC 6%, and capex and opex of ammonia tank addition

e_s_hold_df = pd.DataFrame({
    'r': ['electricity']*2*4 + ['hydrogen']*2*4 + ['e-diesel']*2*4 + ['e-kerosene']*2*4,
    'o': ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2,
    'f': ['out', 'in']*4*4,
    'value': [0, 0, 0, 0, 0, 0, -0.25, 0.75] + [0, 1, 0, 0, 0, 0, 0, 0] + [0, 0, 0, 1, 0, 0, 0, 0] + [0, 0, 0, 0, 0, 1, 0, 0]
})
#for battery was before 'out': -0.002 and 'in': 0.998

e_s_hold_df.to_csv(os.path.join(base_dir, "e_hold_s_new_s2.csv"), index=False) #new because of battery addition

e_s_get_df = pd.DataFrame({
    'r': ['electricity']*2*4 + ['hydrogen']*2*4 + ['e-diesel']*2*4 + ['e-kerosene']*2*4,
    'o': ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2,
    'f': ['out', 'in']*4*4,
    'value': [0, 0, 0, 0, 0, 0, -1, 0.92] + [-1, 1, 0, 0, 0, 0, 0, 0] + [0, 0, -1, 1, 0, 0, 0, 0] + [0, 0, 0, 0, -1, 1, 0, 0]
})

e_s_get_df.to_csv(os.path.join(base_dir, "e_s_get_new_s2.csv"), index=False) #new because of battery addition and change in e-fuel

e_s_put_df = pd.DataFrame({
    'r': ['electricity']*2*4 + ['hydrogen']*2*4 + ['e-diesel']*2*4 + ['e-kerosene']*2*4,
    'o': ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2 + ['large']*2 + ['tank_diesel']*2 + ['tank_kerosene']*2 + ['battery']*2,
    'f': ['out', 'in']*4*4,
    'value': [0, 0, 0, 0, 0, 0, -1, 0.92] + [-1, 1, 0, 0, 0, 0, 0, 0] + [0, 0, -1, 1, 0, 0, 0, 0] + [0, 0, 0, 0, -1, 1, 0, 0]
})

e_s_put_df.to_csv(os.path.join(base_dir, "e_s_put_new_s2.csv"), index=False) #new because of battery addition and change in e-fuel


inj_s_df = pd.DataFrame({
    'o': ['large', 'tank_diesel', 'tank_kerosene', 'battery'],
    'value': [151, 151, 151, 3.3]
})

inj_s_df.to_csv(os.path.join(base_dir, "inj_s_new_s2.csv"), index=False) #new because of battery addition and change in e-fuel

del_s_df = pd.DataFrame({
    'o': ['large', 'tank_diesel', 'tank_kerosene', 'battery'],
    'value': [151, 151, 151, 5]
})

del_s_df.to_csv(os.path.join(base_dir, "del_s_new_s2.csv"), index=False) #new because of battery addition and change in e-fuel

s_min_df = pd.DataFrame({
    'o': ['large', 'tank_diesel', 'tank_kerosene', 'battery'],
    'value': [284, 0, 0, 2]
})

s_min_df.to_csv(os.path.join(base_dir, "s_min_new_s2.csv"), index=False) #new because of battery addition and change in e-fuel

s_max_df = pd.DataFrame({
    'o': ['large', 'tank_diesel', 'tank_kerosene', 'battery'],
    'value': [3630, 3630, 3630, 23.5]
})

s_max_df.to_csv(os.path.join(base_dir, "s_max_new_s2.csv"), index=False) #new because of battery addition and change in e-fuel

#%%
"""
Demand parameters for resources: electricity, hydrogen, e-ammonia, e-methanol, e-kerosene and e-diesel
"""
#Demand of resources in MW/10
electricity = pd.read_csv(r"C:\Data\electricity\electricity_demand.csv")
electricity_demand = pd.melt(electricity, id_vars=['Datetime'], value_vars=['AL', 'HB', 'NA', 'NL', 'RN', 'SL', 'VF', 'VL'])
electricity_demand = electricity_demand.rename({'variable': 'z'}, axis=1)
electricity_demand['Datetime'] = pd.to_datetime(electricity_demand['Datetime'], format='%d/%m/%Y %H:%M')
electricity_demand['Datetime'] = electricity_demand['Datetime'].dt.strftime('%Y-%m-%d %H:%M:%S')
electricity_demand['Datetime_2'] = pd.to_datetime(electricity_demand['Datetime'])

ahc = pd.read_csv(r"C:\Data\wind\AHC.csv")
ahc = ahc.drop('Unnamed: 0', axis=1)
#ahc_list = ahc['Most_Representative_Day'].astype(str).str.slice(0, 10)
ahc = ahc.rename({'Most_Representative_Day': 'Datetime'}, axis=1)
ahc['Datetime'] = pd.to_datetime(ahc['Datetime'])
ahc['Datetime'] = ahc['Datetime'].dt.date
ahc_list = ahc['Datetime'].astype(str).str.slice(0, 10)

mask = electricity_demand['Datetime'].apply(lambda x: any(x.startswith(prefix) for prefix in ahc_list))
electricity_df = electricity_demand[mask]
electricity_df['Datetime_2'] = pd.to_datetime(electricity_df['Datetime'])
electricity_df['Date'] = electricity_df['Datetime_2'].dt.date
electricity_df['h'] = list(range(1,24+1))*64
electricity_df['weekday'] = electricity_df['Datetime_2'].dt.weekday
electricity_df['d'] = electricity_df['weekday'].apply(lambda x: 1 if x < 5 else 2)
electricity_df = electricity_df.drop('Datetime', axis=1)
electricity_df = electricity_df.rename({'Date': 'Datetime'}, axis=1)

electricity_data = pd.merge(electricity_df, ahc, on='Datetime')
electricity_data = electricity_data.rename({'Season': 's'}, axis=1)
electricity_data = electricity_data.drop(['Datetime', 'weekday', 'Day_Type'], axis=1)
electricity_data = electricity_data.sort_values(by=['z', 's', 'd'])
electricity_data['r'] = 'electricity'

demand_df = electricity_data
demand_df['r'] = 'electricity'

maritime = pd.read_csv(r"C:\Data\maritime\maritime_demand.csv")
maritime = maritime.drop('Unnamed: 0', axis=1)
maritime_demand = pd.melt(maritime, id_vars=['Datetime'], value_vars=['AL', 'HB', 'NA', 'NL', 'RN', 'SL', 'VF', 'VL'])
maritime_demand = maritime_demand.rename({'variable': 'z'}, axis=1)
maritime_demand['Datetime'] = pd.to_datetime(maritime_demand['Datetime'], format='%d/%m/%Y %H:%M')
maritime_demand['Datetime'] = maritime_demand['Datetime'].dt.strftime('%Y-%m-%d %H:%M:%S')
maritime_demand['Datetime_2'] = pd.to_datetime(maritime_demand['Datetime'])

mask_2 = maritime_demand['Datetime'].apply(lambda x: any(x.startswith(prefix) for prefix in ahc_list))
maritime_df = maritime_demand[mask_2]
maritime_df = maritime_df.drop('Datetime', axis=1)
maritime_df['h'] = list(range(1,24+1))*64
maritime_df['r'] = 'maritime_fuel'
maritime_df['weekday'] = maritime_df['Datetime_2'].dt.weekday
maritime_df['d'] = maritime_df['weekday'].apply(lambda x: 1 if x < 5 else 2)
maritime_df['Date'] = maritime_df['Datetime_2'].dt.date
maritime_df = maritime_df.rename({'Date': 'Datetime'}, axis=1)

maritime_data = pd.merge(maritime_df, ahc, on='Datetime')
maritime_data = maritime_data.rename({'Season': 's'}, axis=1)
maritime_data = maritime_data.drop(['Datetime', 'weekday', 'Day_Type'], axis=1)
maritime_data = maritime_data.sort_values(by=['z', 's', 'd'])

# methanol_data = maritime_data.copy()
# methanol_data['value'] = methanol_data['value'] *0.4
# methanol_data['r'] = 'e-methanol'
# ammonia_data = maritime_data.copy()
# ammonia_data['value'] = ammonia_data['value'] *0.4
# ammonia_data['r'] = 'e-ammonia'
diesel_data = maritime_data.copy()
diesel_data['value'] = diesel_data['value'] * 1
diesel_data['r'] = 'e-diesel'

demand_df_2 = pd.concat([electricity_data, diesel_data], ignore_index=True)

aviation = pd.read_csv(r"C:\Data\aviation\aviation_demand.csv")
aviation_demand = pd.melt(aviation, id_vars=['Datetime'], value_vars=['AL', 'HB', 'NA', 'NL', 'RN', 'SL', 'VF', 'VL'])
aviation_demand = aviation_demand.rename({'variable': 'z'}, axis=1)

mask_3 = aviation_demand['Datetime'].apply(lambda x: any(x.startswith(prefix) for prefix in ahc_list))
aviation_df = aviation_demand[mask_3]
aviation_df['Datetime_2'] = pd.to_datetime(aviation_df['Datetime'])
aviation_df['Date'] = aviation_df['Datetime_2'].dt.date
aviation_df['h'] = list(range(1,24+1))*64
aviation_df['weekday'] = aviation_df['Datetime_2'].dt.weekday
aviation_df['d'] = aviation_df['weekday'].apply(lambda x: 1 if x < 5 else 2)
aviation_df = aviation_df.drop('Datetime', axis=1)
aviation_df = aviation_df.rename({'Date': 'Datetime'}, axis=1)

aviation_data = pd.merge(aviation_df, ahc, on='Datetime')
aviation_data = aviation_data.rename({'Season': 's'}, axis=1)
aviation_data = aviation_data.drop(['Datetime', 'weekday', 'Day_Type'], axis=1)
aviation_data = aviation_data.sort_values(by=['z', 's', 'd'])
aviation_data['r'] = 'e-kerosene'

demand_df_3 = pd.concat([demand_df_2, aviation_data], ignore_index=True)

hydrogen = pd.read_csv(r"C:\Data\hydrogen\hydrogen_demand.csv")
hydrogen_demand = pd.melt(hydrogen, id_vars=['Datetime'], value_vars=['AL', 'HB', 'NA', 'NL', 'RN', 'SL', 'VF', 'VL'])
hydrogen_demand = hydrogen_demand.rename({'variable': 'z'}, axis=1)

mask_4 = hydrogen_demand['Datetime'].apply(lambda x: any(x.startswith(prefix) for prefix in ahc_list))
hydrogen_df = hydrogen_demand[mask_4]
hydrogen_df['Datetime_2'] = pd.to_datetime(hydrogen_df['Datetime'])
hydrogen_df['Date'] = hydrogen_df['Datetime_2'].dt.date
hydrogen_df['h'] = list(range(1,24+1))*64
hydrogen_df['weekday'] = hydrogen_df['Datetime_2'].dt.weekday
hydrogen_df['d'] = hydrogen_df['weekday'].apply(lambda x: 1 if x < 5 else 2)
hydrogen_df = hydrogen_df.drop('Datetime', axis=1)
hydrogen_df =  hydrogen_df.rename({'Date': 'Datetime'}, axis=1)

hydrogen_data = pd.merge(hydrogen_df, ahc, on='Datetime')
hydrogen_data = hydrogen_data.rename({'Season': 's'}, axis=1)
hydrogen_data = hydrogen_data.drop(['Datetime', 'weekday', 'Day_Type'], axis=1)
hydrogen_data = hydrogen_data.sort_values(by=['z', 's', 'd'])
hydrogen_data['r'] = 'hydrogen'

demand_df_4 = pd.concat([demand_df_3, hydrogen_data], ignore_index=True)

demand_df_4 = demand_df_4.drop('Datetime_2', axis=1)

demand_df_4['value'] = demand_df_4['value']/10

demand_df_4.to_csv(os.path.join(base_dir, "demand_new_s2.csv"), index=False)

# %%
"""
Wind parameters
"""
ahc_wind = pd.read_csv(r"C:\Data\wind\AHC.csv")
ahc_wind = ahc_wind.drop('Unnamed: 0', axis=1)
ahc_list_wind = ahc_wind['Most_Representative_Day'].astype(str).str.slice(0, 10)
ahc_wind = ahc_wind.rename({'Most_Representative_Day': 'Datetime'}, axis=1)
ahc_wind['Datetime'] = pd.to_datetime(ahc_wind['Datetime'])
ahc_wind['Datetime'] = ahc_wind['Datetime'].dt.date

#in MW/10
wind = pd.read_csv(r"C:\Data\wind\average_pivot.csv")
wind_power = pd.melt(wind, id_vars=['Datetime'], value_vars=['AL', 'HB', 'NA', 'NL', 'RN', 'SL', 'VF', 'VL'])
wind_power = wind_power.rename({'variable': 'z'}, axis=1)
wind_power['Datetime_2'] = pd.to_datetime(wind_power['Datetime']) #, format='%d/%m/%Y %H:%M')
wind_power['Datetime'] = wind_power['Datetime_2'].astype(str)

mask_5 = wind_power['Datetime'].apply(lambda x: any(x.startswith(prefix) for prefix in ahc_list_wind))
wind_df = wind_power[mask_5]
wind_df = wind_df.drop('Datetime', axis=1)
wind_df['h'] = list(range(1,24+1))*64
wind_df['r'] = 'electricity'
wind_df['weekday'] = wind_df['Datetime_2'].dt.weekday
wind_df['d'] = wind_df['weekday'].apply(lambda x: 1 if x < 5 else 2)
wind_df['Date'] = wind_df['Datetime_2'].dt.date
wind_df =wind_df.rename({'Date': 'Datetime'}, axis=1)
#wind_df['Datetime'] = pd.to_datetime(wind_df['Datetime'])

wind_data = pd.merge(wind_df, ahc_wind, on='Datetime')
wind_data = wind_data.rename({'Season': 's'}, axis=1)
wind_data = wind_data.drop(['Datetime', 'weekday', 'd'], axis=1)
wind_data = wind_data.rename({'Day_Type': 'd'}, axis=1)
wind_data = wind_data.sort_values(by=['z', 's', 'd'])

wind_data = wind_data.drop('Datetime_2', axis=1)

wind_data['value'] = wind_data['value']/10

wind_data.to_csv(os.path.join(base_dir, "wind_new_s2.csv"), index=False)